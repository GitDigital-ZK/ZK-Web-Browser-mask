/**
 * ZK Web Browser Mask - Cryptographic Services
 * 
 * Provides cryptographic operations for the ZK Web Browser Mask SDK.
 */

import { ICryptoService } from './types';

/**
 * CryptoService - Cryptographic operations implementation
 * 
 * Implements cryptographic primitives using the WebCrypto API
 * for secure, standards-compliant operations.
 */
export class CryptoService implements ICryptoService {
  /**
   * SHA-256 hash function
   */
  public async hash(data: Uint8Array): Promise<Uint8Array> {
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return new Uint8Array(hashBuffer);
  }

  /**
   * Generate cryptographically secure random bytes
   */
  public async generateRandomBytes(length: number): Promise<Uint8Array> {
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    return array;
  }

  /**
   * Encrypt data using AES-GCM
   */
  public async encrypt(data: Uint8Array, key: CryptoKey): Promise<Uint8Array> {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    
    const encryptedBuffer = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv
      },
      key,
      data
    );

    // Prepend IV to encrypted data
    const result = new Uint8Array(iv.length + encryptedBuffer.byteLength);
    result.set(iv, 0);
    result.set(new Uint8Array(encryptedBuffer), iv.length);
    
    return result;
  }

  /**
   * Decrypt data using AES-GCM
   */
  public async decrypt(data: Uint8Array, key: CryptoKey): Promise<Uint8Array> {
    const iv = data.slice(0, 12);
    const ciphertext = data.slice(12);

    const decryptedBuffer = await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv
      },
      key,
      ciphertext
    );

    return new Uint8Array(decryptedBuffer);
  }

  /**
   * Generate an AES-256-GCM key
   */
  public async generateKey(): Promise<CryptoKey> {
    return crypto.subtle.generateKey(
      {
        name: 'AES-GCM',
        length: 256
      },
      true, // extractable
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Derive a key from a password using PBKDF2
   */
  public async deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
    const passwordBuffer = new TextEncoder().encode(password);
    
    // Import password as key material
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      passwordBuffer,
      'PBKDF2',
      false,
      ['deriveBits', 'deriveKey']
    );

    // Derive AES key from password
    return crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt,
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      {
        name: 'AES-GCM',
        length: 256
      },
      true,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Export key to raw bytes
   */
  public async exportKey(key: CryptoKey): Promise<Uint8Array> {
    const exported = await crypto.subtle.exportKey('raw', key);
    return new Uint8Array(exported);
  }

  /**
   * Import key from raw bytes
   */
  public async importKey(keyData: Uint8Array): Promise<CryptoKey> {
    return crypto.subtle.importKey(
      'raw',
      keyData,
      {
        name: 'AES-GCM',
        length: 256
      },
      true,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Generate a random salt for key derivation
   */
  public async generateSalt(): Promise<Uint8Array> {
    return this.generateRandomBytes(16);
  }

  /**
   * Perform elliptic curve point addition
   * Used in ZK proof circuits
   */
  public async ecAdd(
    point1: Uint8Array,
    point2: Uint8Array,
    curve: 'bn128' | 'bls12_381'
  ): Promise<Uint8Array> {
    // Simplified implementation - in production use a proper EC library
    const result = new Uint8Array(point1.length);
    for (let i = 0; i < point1.length; i++) {
      result[i] = (point1[i] + point2[i]) % 256;
    }
    return result;
  }

  /**
   * Perform elliptic curve scalar multiplication
   * Used in ZK proof circuits
   */
  public async ecMul(
    point: Uint8Array,
    scalar: Uint8Array,
    curve: 'bn128' | 'bls12_381'
  ): Promise<Uint8Array> {
    // Simplified implementation - in production use a proper EC library
    const result = new Uint8Array(point.length);
    const scalarNum = scalar.reduce((acc, b) => acc * 256 + b, 0);
    for (let i = 0; i < point.length; i++) {
      result[i] = (point[i] * scalarNum) % 256;
    }
    return result;
  }

  /**
   * Hash multiple values together
   */
  public async hashMultiple(values: Uint8Array[]): Promise<Uint8Array> {
    const combined = new Uint8Array(
      values.reduce((acc, v) => acc + v.length, 0)
    );
    
    let offset = 0;
    for (const value of values) {
      combined.set(value, offset);
      offset += value.length;
    }

    return this.hash(combined);
  }

  /**
   * Create a commitment from a value and randomness
   * commitment = hash(value || randomness)
   */
  public async createCommitment(
    value: Uint8Array,
    randomness: Uint8Array
  ): Promise<Uint8Array> {
    const combined = new Uint8Array(value.length + randomness.length);
    combined.set(value, 0);
    combined.set(randomness, value.length);
    return this.hash(combined);
  }

  /**
   * Verify a Merkle proof
   */
  public async verifyMerkleProof(
    leaf: Uint8Array,
    proof: Uint8Array[],
    root: Uint8Array,
    indices: number[]
  ): Promise<boolean> {
    let current = leaf;

    for (let i = 0; i < proof.length; i++) {
      const sibling = proof[i];
      const isRight = indices[i] === 1;

      const combined = isRight
        ? new Uint8Array([...current, ...sibling])
        : new Uint8Array([...sibling, ...current]);

      current = await this.hash(combined);
    }

    // Compare with root
    if (current.length !== root.length) {
      return false;
    }

    for (let i = 0; i < current.length; i++) {
      if (current[i] !== root[i]) {
        return false;
      }
    }

    return true;
  }
}

/**
 * Poseidon hash function implementation
 * Used in ZK circuits for efficient hashing
 */
export class PoseidonHash {
  private static readonly ROUND_CONSTANTS = [
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
    33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
    56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78,
    79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101,
    102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120
  ];

  /**
   * Compute Poseidon hash of input values
   */
  public static hash(inputs: bigint[]): bigint {
    let state = [...inputs, ...Array(12 - inputs.length).fill(0n)];

    // 8 full rounds
    for (let r = 0; r < 8; r++) {
      state = state.map((s, i) => s + BigInt(this.ROUND_CONSTANTS[r * 12 + i]));
      state = state.map(s => this.pow5(s));
      state = this.mdsMix(state);
    }

    // 56 partial rounds
    for (let r = 0; r < 56; r++) {
      state[0] = state[0] + BigInt(this.ROUND_CONSTANTS[96 + r]);
      state[0] = this.pow5(state[0]);
      
      const newState = [state[0]];
      for (let i = 1; i < 12; i++) {
        newState.push(state[i]);
      }
      state = this.mdsMix(newState);
    }

    // 8 full rounds
    for (let r = 0; r < 8; r++) {
      state = state.map((s, i) => s + BigInt(this.ROUND_CONSTANTS[152 + r * 12 + i]));
      state = state.map(s => this.pow5(s));
      state = this.mdsMix(state);
    }

    return state[0];
  }

  private static pow5(x: bigint): bigint {
    const x2 = (x * x) % this.MODULUS;
    const x4 = (x2 * x2) % this.MODULUS;
    return (x4 * x) % this.MODULUS;
  }

  private static mdsMix(state: bigint[]): bigint[] {
    const result = new Array(12).fill(0n);
    for (let i = 0; i < 12; i++) {
      for (let j = 0; j < 12; j++) {
        result[i] = (result[i] + BigInt(this.MDS[i * 12 + j]) * state[j]) % this.MODULUS;
      }
    }
    return result;
  }

  // BN128 scalar field modulus
  private static readonly MODULUS = 21888242871839275222246405745257275088548364400416034343698204186575808495617n;
  
  // MDS matrix (simplified - actual implementation would use proper MDS)
  private static readonly MDS = Array(144).fill(1n).map((_, i) => BigInt(i % 12 === i / 12 ? 2 : 1));
}

/**
 * Pedersen commitment scheme implementation
 */
export class PedersenCommitment {
  /**
   * Create a Pedersen commitment
   * commitment = g^value * h^randomness
   */
  public static commit(
    value: bigint,
    randomness: bigint,
    g: bigint,
    h: bigint
  ): bigint {
    // Simplified - in production use proper elliptic curve operations
    return (value * g + randomness * h) % PedersenCommitment.MODULUS;
  }

  private static readonly MODULUS = 21888242871839275222246405745257275088548364400416034343698204186575808495617n;
}
