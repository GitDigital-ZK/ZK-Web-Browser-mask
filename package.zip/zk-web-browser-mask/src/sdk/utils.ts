/**
 * ZK Web Browser Mask - Utility Functions
 * 
 * Common utility functions for the SDK.
 */

import { MaskAttributes, AttributeValue } from './types';

/**
 * Hash attributes with a salt to create a commitment
 */
export async function hashAttributes(
  attributes: MaskAttributes,
  salt: Uint8Array
): Promise<Uint8Array> {
  const encoder = new TextEncoder();
  
  // Sort attribute keys for deterministic ordering
  const sortedKeys = Object.keys(attributes).sort();
  
  // Combine all attribute values
  const values: Uint8Array[] = [];
  for (const key of sortedKeys) {
    const attr = attributes[key];
    values.push(encoder.encode(key));
    values.push(attributeToBytes(attr));
  }
  
  // Combine with salt
  const combined = new Uint8Array(
    salt.length + values.reduce((sum, v) => sum + v.length, 0)
  );
  
  let offset = 0;
  combined.set(salt, offset);
  offset += salt.length;
  
  for (const value of values) {
    combined.set(value, offset);
    offset += value.length;
  }
  
  // Hash the combined data
  const hashBuffer = await crypto.subtle.digest('SHA-256', combined);
  return new Uint8Array(hashBuffer);
}

/**
 * Convert attribute value to bytes
 */
export function attributeToBytes(attr: AttributeValue): Uint8Array {
  switch (attr.type) {
    case 'uint8':
      return new Uint8Array([attr.value]);
    case 'uint32':
      const buf32 = new ArrayBuffer(4);
      new DataView(buf32).setUint32(0, attr.value);
      return new Uint8Array(buf32);
    case 'uint64':
      const buf64 = new ArrayBuffer(8);
      new DataView(buf64).setBigUint64(0, attr.value);
      return new Uint8Array(buf64);
    case 'boolean':
      return new Uint8Array([attr.value ? 1 : 0]);
    case 'string':
      return new TextEncoder().encode(attr.value);
    case 'bytes':
      return attr.value;
    default:
      return new Uint8Array(0);
  }
}

/**
 * Parse attribute value from bytes
 */
export function bytesToAttribute(bytes: Uint8Array, type: string): AttributeValue['value'] {
  switch (type) {
    case 'uint8':
      return bytes[0];
    case 'uint32':
      return new DataView(bytes.buffer).getUint32(0);
    case 'uint64':
      return new DataView(bytes.buffer).getBigUint64(0);
    case 'boolean':
      return bytes[0] === 1;
    case 'string':
      return new TextDecoder().decode(bytes);
    case 'bytes':
      return bytes;
    default:
      throw new Error(`Unknown attribute type: ${type}`);
  }
}

/**
 * Generate a random salt
 */
export async function randomSalt(length: number = 32): Promise<Uint8Array> {
  const salt = new Uint8Array(length);
  crypto.getRandomValues(salt);
  return salt;
}

/**
 * Merkle Tree implementation for commitment aggregation
 */
export class MerkleTree {
  private leaves: Uint8Array[];
  private levels: Uint8Array[][];
  private depth: number;

  constructor(leaves: Uint8Array[], depth?: number) {
    this.leaves = leaves;
    this.depth = depth || Math.ceil(Math.log2(leaves.length)) + 1;
    this.levels = [];
    this.build();
  }

  /**
   * Build the Merkle tree
   */
  private async build(): Promise<void> {
    let currentLevel = this.leaves.map(l => l);

    // Hash leaves if needed
    for (let i = 0; i < currentLevel.length; i++) {
      if (currentLevel[i].length !== 32) {
        const hash = await crypto.subtle.digest('SHA-256', currentLevel[i]);
        currentLevel[i] = new Uint8Array(hash);
      }
    }

    this.levels.push(currentLevel);

    // Build subsequent levels
    while (currentLevel.length > 1) {
      const nextLevel: Uint8Array[] = [];

      for (let i = 0; i < currentLevel.length; i += 2) {
        const left = currentLevel[i];
        const right = i + 1 < currentLevel[i].length ? currentLevel[i + 1] : left;

        const combined = new Uint8Array(left.length + right.length);
        combined.set(left, 0);
        combined.set(right, left.length);

        const hash = await crypto.subtle.digest('SHA-256', combined);
        nextLevel.push(new Uint8Array(hash));
      }

      this.levels.push(nextLevel);
      currentLevel = nextLevel;
    }
  }

  /**
   * Get the Merkle root
   */
  public getRoot(): Uint8Array {
    return this.levels[this.levels.length - 1][0];
  }

  /**
   * Generate a Merkle proof for a leaf
   */
  public async getProof(index: number): Promise<MerkleProof> {
    if (index < 0 || index >= this.leaves.length) {
      throw new Error('Invalid leaf index');
    }

    const proof: Uint8Array[] = [];
    const positions: number[] = [];
    let currentIndex = index;

    for (let level = 0; level < this.levels.length - 1; level++) {
      const siblingIndex = currentIndex % 2 === 0 ? currentIndex + 1 : currentIndex - 1;
      const sibling = this.levels[level][siblingIndex] || this.levels[level][currentIndex];
      
      proof.push(sibling);
      positions.push(currentIndex % 2);

      currentIndex = Math.floor(currentIndex / 2);
    }

    return {
      leaf: this.leaves[index],
      proof,
      positions,
      root: this.getRoot()
    };
  }

  /**
   * Verify a Merkle proof
   */
  public static async verify(proof: MerkleProof): Promise<boolean> {
    let current = proof.leaf;

    // Hash leaf if needed
    if (current.length !== 32) {
      const hash = await crypto.subtle.digest('SHA-256', current);
      current = new Uint8Array(hash);
    }

    for (let i = 0; i < proof.proof.length; i++) {
      const sibling = proof.proof[i];
      const isRight = proof.positions[i] === 1;

      const combined = isRight
        ? new Uint8Array([...current, ...sibling])
        : new Uint8Array([...sibling, ...current]);

      const hash = await crypto.subtle.digest('SHA-256', combined);
      current = new Uint8Array(hash);
    }

    // Compare with root
    if (current.length !== proof.root.length) {
      return false;
    }

    for (let i = 0; i < current.length; i++) {
      if (current[i] !== proof.root[i]) {
        return false;
      }
    }

    return true;
  }
}

/**
 * Merkle proof structure
 */
export interface MerkleProof {
  leaf: Uint8Array;
  proof: Uint8Array[];
  positions: number[];
  root: Uint8Array;
}

/**
 * Convert bytes to hex string
 */
export function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * Convert hex string to bytes
 */
export function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

/**
 * Convert bytes to base64 string
 */
export function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Convert base64 string to bytes
 */
export function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Validate an attribute value against its type
 */
export function validateAttributeValue(value: unknown, type: string): boolean {
  switch (type) {
    case 'uint8':
      return typeof value === 'number' && value >= 0 && value <= 255 && Number.isInteger(value);
    case 'uint32':
      return typeof value === 'number' && value >= 0 && value <= 4294967295 && Number.isInteger(value);
    case 'uint64':
      return typeof value === 'bigint' || (typeof value === 'number' && Number.isInteger(value));
    case 'boolean':
      return typeof value === 'boolean';
    case 'string':
      return typeof value === 'string';
    case 'bytes':
      return value instanceof Uint8Array;
    default:
      return false;
  }
}

/**
 * Deep clone an object
 */
export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

/**
 * Compare two arrays for equality
 */
export function arraysEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) {
    return false;
  }
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) {
      return false;
    }
  }
  return true;
}

/**
 * Concatenate multiple byte arrays
 */
export function concatBytes(...arrays: Uint8Array[]): Uint8Array {
  const totalLength = arrays.reduce((sum, arr) => sum + arr.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const arr of arrays) {
    result.set(arr, offset);
    offset += arr.length;
  }
  return result;
}

export {
  hashAttributes,
  attributeToBytes,
  bytesToAttribute,
  randomSalt,
  MerkleTree,
  bytesToHex,
  hexToBytes,
  bytesToBase64,
  base64ToBytes,
  validateAttributeValue,
  deepClone,
  arraysEqual,
  concatBytes
};
