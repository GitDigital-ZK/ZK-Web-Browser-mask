/**
 * ZK Web Browser Mask SDK
 * 
 * A comprehensive SDK for privacy-preserving identity verification using
 * zero-knowledge proofs in web applications.
 * 
 * @example
 * ```typescript
 * import { ZKWebBrowserMask, ZKVerifier } from 'zk-web-browser-mask-sdk';
 * 
 * // Create a mask
 * const mask = new ZKWebBrowserMask({
 *   attributes: {
 *     age: { type: 'uint8', value: 25 },
 *     country: { type: 'string', value: 'US' }
 *   }
 * });
 * 
 * await mask.initialize();
 * 
 * // Generate proof
 * const proof = await mask.generateProof({
 *   constraints: [{ attribute: 'age', operator: '>=', value: 18 }]
 * });
 * 
 * // Verify proof
 * const verifier = new ZKVerifier({});
 * const result = await verifier.verify(proof);
 * ```
 */

// Core classes
export { ZKWebBrowserMask } from './mask';
export { ZKVerifier } from './verifier';
export { ZKProver, CircuitBuilder } from './prover';
export { CryptoService, PoseidonHash, PedersenCommitment } from './crypto';
export { StorageManager } from './storage';

// Utilities
export {
  hashAttributes,
  attributeToBytes,
  bytesToAttribute,
  randomSalt,
  MerkleTree,
  MerkleProof,
  bytesToHex,
  hexToBytes,
  bytesToBase64,
  base64ToBytes,
  validateAttributeValue,
  deepClone,
  arraysEqual,
  concatBytes
} from './utils';

// Types
export {
  MaskAttributes,
  AttributeValue,
  AttributeType,
  Constraint,
  ConstraintOperator,
  ProofRequest,
  PublicSignals,
  ZKProof,
  VerificationResult,
  ZKMaskConfig,
  ZKProofConfig,
  ZKVerifierConfig,
  VerificationKey,
  VerificationOptions,
  StorageBackend,
  Commitment,
  Nullifier,
  ExportedMask,
  MaskInfo,
  ConsentRequest,
  AuditLogEntry,
  ZKBrowserAPI,
  IStorageManager,
  ICryptoService,
  IZKProver,
  IZKVerifier,
  ZKError,
  ZKErrorType
} from './types';

/**
 * SDK Version
 */
export const VERSION = '1.0.0';

/**
 * Supported curves
 */
export const SUPPORTED_CURVES = ['bn128', 'bls12_381'] as const;

/**
 * Supported proving schemes
 */
export const SUPPORTED_SCHEMES = ['groth16', 'plonk'] as const;

/**
 * SDK metadata
 */
export const SDK_INFO = {
  version: VERSION,
  name: 'ZK Web Browser Mask SDK',
  description: 'Privacy-preserving identity verification using zero-knowledge proofs',
  supportedCurves: SUPPORTED_CURVES,
  supportedSchemes: SUPPORTED_SCHEMES,
  repository: 'https://github.com/your-org/zk-web-browser-mask',
  documentation: 'https://docs.zkwebbrowsermask.org'
};

/**
 * Check if the environment supports the required cryptographic operations
 */
export function checkEnvironmentSupport(): EnvironmentSupport {
  const checks = {
    webCrypto: typeof crypto !== 'undefined' && typeof crypto.subtle !== 'undefined',
    indexedDB: typeof indexedDB !== 'undefined',
    webAssembly: typeof WebAssembly !== 'undefined',
    cryptoGetRandomValues: typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function'
  };

  const isSupported = checks.webCrypto && checks.cryptoGetRandomValues;

  return {
    isSupported,
    checks,
    recommendations: generateRecommendations(checks)
  };
}

/**
 * Environment support check result
 */
interface EnvironmentSupport {
  isSupported: boolean;
  checks: {
    webCrypto: boolean;
    indexedDB: boolean;
    webAssembly: boolean;
    cryptoGetRandomValues: boolean;
  };
  recommendations: string[];
}

function generateRecommendations(checks: Record<string, boolean>): string[] {
  const recommendations: string[] = [];

  if (!checks.webCrypto) {
    recommendations.push('WebCrypto API not available. Some features may not work.');
  }

  if (!checks.indexedDB) {
    recommendations.push('IndexedDB not available. Using localStorage fallback.');
  }

  if (!checks.webAssembly) {
    recommendations.push('WebAssembly not available. Performance may be reduced.');
  }

  if (!checks.cryptoGetRandomValues) {
    recommendations.push('Secure random number generation not available.');
  }

  return recommendations;
}

/**
 * Initialize the SDK with optional configuration
 */
export async function initializeSDK(config?: {
  storageBackend?: 'indexeddb' | 'localStorage' | 'memory';
  encryptionKey?: CryptoKey | null;
}): Promise<void> {
  // Check environment support
  const support = checkEnvironmentSupport();
  
  if (!support.isSupported) {
    throw new Error(
      'Insufficient environment support. Please use a modern browser with WebCrypto API.'
    );
  }

  // Pre-warm caches and initialize modules
  // This can be extended for additional initialization tasks
  console.info('ZK Web Browser Mask SDK initialized', SDK_INFO);
}

export default {
  ZKWebBrowserMask,
  ZKVerifier,
  ZKProver,
  CircuitBuilder,
  CryptoService,
  StorageManager,
  PoseidonHash,
  PedersenCommitment,
  MerkleTree,
  VERSION,
  SDK_INFO,
  SUPPORTED_CURVES,
  SUPPORTED_SCHEMES,
  checkEnvironmentSupport,
  initializeSDK
};
