/**
 * ZK Web Browser Mask - Type Definitions
 * 
 * This file contains all type definitions and interfaces for the ZK Web Browser Mask SDK.
 */

/**
 * Attribute value types supported by the mask system
 */
export type AttributeType = 'uint8' | 'uint32' | 'uint64' | 'boolean' | 'string' | 'bytes';

/**
 * Union type for all possible attribute values
 */
export type AttributeValue = 
  | { type: 'uint8'; value: number }
  | { type: 'uint32'; value: number }
  | { type: 'uint64'; value: bigint }
  | { type: 'boolean'; value: boolean }
  | { type: 'string'; value: string }
  | { type: 'bytes'; value: Uint8Array };

/**
 * Collection of mask attributes
 */
export interface MaskAttributes {
  [key: string]: AttributeValue;
}

/**
 * Constraint operators for proof generation
 */
export type ConstraintOperator = '==' | '!=' | '>' | '<' | '>=' | '<=' | 'in' | 'notIn';

/**
 * Individual constraint definition
 */
export interface Constraint {
  attribute: string;
  operator: ConstraintOperator;
  value: number | string | boolean | bigint | number[] | string[];
}

/**
 * Proof request configuration
 */
export interface ProofRequest {
  constraints: Constraint[];
  issuer?: string;
  audience?: string;
  expiration?: number;
  nonce?: Uint8Array;
  metadata?: Record<string, unknown>;
  circuit?: string;
  provingTime?: 'speed' | 'balanced' | 'security';
}

/**
 * Public signals revealed by the proof
 */
export interface PublicSignals {
  commitment: string;
  nullifier: string;
  issuer?: string;
  revealedAttributes?: Record<string, unknown>;
  timestamp?: number;
  [key: string]: unknown;
}

/**
 * Zero-knowledge proof data structure
 */
export interface ZKProof {
  proofData: Uint8Array;
  publicSignals: PublicSignals;
  proofType: string;
  createdAt: number;
  expiresAt?: number;
  issuer?: string;
  nullifier: Uint8Array;
  constraints: Constraint[];
}

/**
 * Verification result from the verifier
 */
export interface VerificationResult {
  isValid: boolean;
  publicSignals: PublicSignals;
  nullifier: string;
  failedConstraints?: Constraint[];
  error?: string;
  metadata?: Record<string, unknown>;
}

/**
 * Configuration for the ZK Web Browser Mask
 */
export interface ZKMaskConfig {
  attributes: MaskAttributes;
  config?: ZKProofConfig;
  storageBackend?: StorageBackend;
  encryptionKey?: CryptoKey | null;
  rpcEndpoint?: string;
  commitmentRegistry?: string;
  requireUserConsent?: boolean;
  auditLogging?: boolean;
}

/**
 * ZK proof configuration options
 */
export interface ZKProofConfig {
  curve: 'bn128' | 'bls12_381';
  provingScheme: 'groth16' | 'plonk';
  provingKey?: Uint8Array;
  verificationKey?: Uint8Array;
}

/**
 * Storage backend options
 */
export type StorageBackend = 'indexeddb' | 'localStorage' | 'memory';

/**
 * Verifier configuration
 */
export interface ZKVerifierConfig {
  trustedIssuers?: Map<string, VerificationKey>;
  verificationKey?: VerificationKey;
  options?: VerificationOptions;
}

/**
 * Verification key for trusted issuers
 */
export interface VerificationKey {
  id: string;
  keyData: Uint8Array;
  curve: 'bn128' | 'bls12_381';
  provingScheme: 'groth16' | 'plonk';
}

/**
 * Verification options
 */
export interface VerificationOptions {
  checkExpiration?: boolean;
  maxProofAge?: number;
  checkNullifier?: boolean;
  allowRevocation?: boolean;
  requireAudience?: boolean;
  allowedAudiences?: string[];
}

/**
 * Commitment data structure
 */
export interface Commitment {
  value: Uint8Array;
  salt: Uint8Array;
  attributesHash: Uint8Array;
  createdAt: number;
}

/**
 * Nullifier for proof uniqueness
 */
export interface Nullifier {
  value: Uint8Array;
  commitment: Uint8Array;
  secret: Uint8Array;
}

/**
 * Exported mask data for backup
 */
export interface ExportedMask {
  version: string;
  commitment: string;
  nullifier: string;
  attributes: MaskAttributes;
  encryptedSecret?: string;
  createdAt: number;
  expiresAt?: number;
}

/**
 * Storage interface for mask persistence
 */
export interface IStorageManager {
  save(key: string, data: Uint8Array): Promise<void>;
  load(key: string): Promise<Uint8Array | null>;
  delete(key: string): Promise<void>;
  exists(key: string): Promise<boolean>;
  list(): Promise<string[]>;
  clear(): Promise<void>;
}

/**
 * Cryptographic service interface
 */
export interface ICryptoService {
  hash(data: Uint8Array): Promise<Uint8Array>;
  generateRandomBytes(length: number): Promise<Uint8Array>;
  encrypt(data: Uint8Array, key: CryptoKey): Promise<Uint8Array>;
  decrypt(data: Uint8Array, key: CryptoKey): Promise<Uint8Array>;
  generateKey(): Promise<CryptoKey>;
  deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey>;
}

/**
 * ZK Prover interface
 */
export interface IZKProver {
  initialize(config: ZKProofConfig): Promise<void>;
  generateProof(constraints: Constraint[], privateInputs: Uint8Array[], publicInputs: Uint8Array[]): Promise<Uint8Array>;
  getPublicSignals(): Uint8Array[];
}

/**
 * ZK Verifier interface
 */
export interface IZKVerifier {
  initialize(config: ZKProofConfig, verificationKey: VerificationKey): Promise<void>;
  verify(proof: Uint8Array, publicSignals: Uint8Array[]): Promise<boolean>;
}

/**
 * Browser extension API
 */
export interface ZKBrowserAPI {
  hasMask(domain: string): Promise<boolean>;
  requestProof(request: ProofRequest): Promise<ZKProof>;
  getMasks(domain: string): Promise<MaskInfo[]>;
  registerMask(attributes: MaskAttributes): Promise<Commitment>;
  getConsentRequests(): Promise<ConsentRequest[]>;
  respondToConsent(requestId: string, granted: boolean): Promise<void>;
}

/**
 * Mask information for extension UI
 */
export interface MaskInfo {
  id: string;
  commitment: string;
  attributes: MaskAttributes;
  createdAt: number;
  expiresAt?: number;
  domains: string[];
}

/**
 * User consent request from a website
 */
export interface ConsentRequest {
  id: string;
  domain: string;
  constraints: Constraint[];
  reason: string;
  timestamp: number;
}

/**
 * Audit log entry
 */
export interface AuditLogEntry {
  id: string;
  action: 'mask_created' | 'mask_revoked' | 'proof_generated' | 'proof_verified' | 'mask_imported' | 'mask_exported';
  timestamp: number;
  details: Record<string, unknown>;
  domain?: string;
  proofType?: string;
}

/**
 * Error types for the SDK
 */
export enum ZKErrorType {
  INVALID_CONFIG = 'INVALID_CONFIG',
  PROOF_GENERATION_FAILED = 'PROOF_GENERATION_FAILED',
  VERIFICATION_FAILED = 'VERIFICATION_FAILED',
  INVALID_CONSTRAINT = 'INVALID_CONSTRAINT',
  MISSING_ATTRIBUTE = 'MISSING_ATTRIBUTE',
  STORAGE_ERROR = 'STORAGE_ERROR',
  CRYPTO_ERROR = 'CRYPTO_ERROR',
  NETWORK_ERROR = 'NETWORK_ERROR',
  TIMEOUT = 'TIMEOUT',
  USER_REJECTED = 'USER_REJECTED',
  EXPIRED = 'EXPIRED',
  REVOKED = 'REVOKED'
}

/**
 * Custom error class for ZK operations
 */
export class ZKError extends Error {
  constructor(
    public type: ZKErrorType,
    message: string,
    public details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'ZKError';
  }
}

/**
 * Re-export commonly used types
 */
export type {
  MaskAttributes,
  Constraint,
  ProofRequest,
  ZKProof,
  VerificationResult,
  ZKMaskConfig,
  Commitment,
  PublicSignals
};
