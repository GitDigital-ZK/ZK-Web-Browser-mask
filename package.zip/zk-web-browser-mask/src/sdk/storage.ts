/**
 * ZK Web Browser Mask - Storage Manager
 * 
 * Secure storage management for mask data using IndexedDB, localStorage, or memory.
 */

import { IStorageManager, StorageBackend, ZKError, ZKErrorType } from './types';

/**
 * StorageManager - Unified storage interface
 * 
 * Provides a consistent API for storing mask data across different backends,
 * with optional encryption support.
 */
export class StorageManager implements IStorageManager {
  private backend: StorageBackend;
  private encryptionKey: CryptoKey | null;
  private memoryStore: Map<string, Uint8Array>;

  constructor(config: { backend?: StorageBackend; encryptionKey?: CryptoKey | null }) {
    this.backend = config.backend || 'indexeddb';
    this.encryptionKey = config.encryptionKey || null;
    this.memoryStore = new Map();
  }

  /**
   * Save data to storage
   */
  public async save(key: string, data: Uint8Array): Promise<void> {
    try {
      const dataToStore = this.encryptionKey
        ? await this.encryptData(data)
        : data;

      switch (this.backend) {
        case 'indexeddb':
          await this.saveToIndexedDB(key, dataToStore);
          break;
        case 'localStorage':
          await this.saveToLocalStorage(key, dataToStore);
          break;
        case 'memory':
          this.memoryStore.set(key, dataToStore);
          break;
      }
    } catch (error) {
      throw new ZKError(
        ZKErrorType.STORAGE_ERROR,
        `Failed to save data: ${error instanceof Error ? error.message : 'Unknown error'}`,
        { key }
      );
    }
  }

  /**
   * Load data from storage
   */
  public async load(key: string): Promise<Uint8Array | null> {
    try {
      let data: Uint8Array | null = null;

      switch (this.backend) {
        case 'indexeddb':
          data = await this.loadFromIndexedDB(key);
          break;
        case 'localStorage':
          data = await this.loadFromLocalStorage(key);
          break;
        case 'memory':
          data = this.memoryStore.get(key) || null;
          break;
      }

      if (data && this.encryptionKey) {
        data = await this.decryptData(data);
      }

      return data;
    } catch (error) {
      throw new ZKError(
        ZKErrorType.STORAGE_ERROR,
        `Failed to load data: ${error instanceof Error ? error.message : 'Unknown error'}`,
        { key }
      );
    }
  }

  /**
   * Delete data from storage
   */
  public async delete(key: string): Promise<void> {
    try {
      switch (this.backend) {
        case 'indexeddb':
          await this.deleteFromIndexedDB(key);
          break;
        case 'localStorage':
          this.deleteFromLocalStorage(key);
          break;
        case 'memory':
          this.memoryStore.delete(key);
          break;
      }
    } catch (error) {
      throw new ZKError(
        ZKErrorType.STORAGE_ERROR,
        `Failed to delete data: ${error instanceof Error ? error.message : 'Unknown error'}`,
        { key }
      );
    }
  }

  /**
   * Check if a key exists in storage
   */
  public async exists(key: string): Promise<boolean> {
    try {
      switch (this.backend) {
        case 'indexeddb':
          return await this.existsInIndexedDB(key);
        case 'localStorage':
          return this.existsInLocalStorage(key);
        case 'memory':
          return this.memoryStore.has(key);
      }
    } catch (error) {
      return false;
    }
  }

  /**
   * List all keys in storage
   */
  public async list(): Promise<string[]> {
    try {
      switch (this.backend) {
        case 'indexeddb':
          return await this.listIndexedDBKeys();
        case 'localStorage':
          return this.listLocalStorageKeys();
        case 'memory':
          return Array.from(this.memoryStore.keys());
      }
    } catch (error) {
      throw new ZKError(
        ZKErrorType.STORAGE_ERROR,
        `Failed to list keys: ${error instanceof Error ? error.message : 'Unknown error'}`
      );
    }
  }

  /**
   * Clear all data from storage
   */
  public async clear(): Promise<void> {
    try {
      switch (this.backend) {
        case 'indexeddb':
          await this.clearIndexedDB();
          break;
        case 'localStorage':
          this.clearLocalStorage();
          break;
        case 'memory':
          this.memoryStore.clear();
          break;
      }
    } catch (error) {
      throw new ZKError(
        ZKErrorType.STORAGE_ERROR,
        `Failed to clear storage: ${error instanceof Error ? error.message : 'Unknown error'}`
      );
    }
  }

  // IndexedDB implementation

  private async getDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('zk-web-browser-mask', 1);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('masks')) {
          db.createObjectStore('masks', { keyPath: 'key' });
        }
      };
    });
  }

  private async saveToIndexedDB(key: string, data: Uint8Array): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['masks'], 'readwrite');
      const store = transaction.objectStore('masks');
      const request = store.put({ key, data: Array.from(data) });

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  }

  private async loadFromIndexedDB(key: string): Promise<Uint8Array | null> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['masks'], 'readonly');
      const store = transaction.objectStore('masks');
      const request = store.get(key);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const result = request.result;
        resolve(result ? new Uint8Array(result.data) : null);
      };
    });
  }

  private async deleteFromIndexedDB(key: string): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['masks'], 'readwrite');
      const store = transaction.objectStore('masks');
      const request = store.delete(key);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  }

  private async existsInIndexedDB(key: string): Promise<boolean> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['masks'], 'readonly');
      const store = transaction.objectStore('masks');
      const request = store.count(key);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result > 0);
    });
  }

  private async listIndexedDBKeys(): Promise<string[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['masks'], 'readonly');
      const store = transaction.objectStore('masks');
      const request = store.getAllKeys();

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result.map(String));
    });
  }

  private async clearIndexedDB(): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(['masks'], 'readwrite');
      const store = transaction.objectStore('masks');
      const request = store.clear();

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  }

  // localStorage implementation

  private async saveToLocalStorage(key: string, data: Uint8Array): Promise<void> {
    const base64 = this.uint8ArrayToBase64(data);
    localStorage.setItem(`zk_mask_${key}`, base64);
  }

  private async loadFromLocalStorage(key: string): Promise<Uint8Array | null> {
    const base64 = localStorage.getItem(`zk_mask_${key}`);
    if (!base64) return null;
    return this.base64ToUint8Array(base64);
  }

  private deleteFromLocalStorage(key: string): void {
    localStorage.removeItem(`zk_mask_${key}`);
  }

  private existsInLocalStorage(key: string): boolean {
    return localStorage.getItem(`zk_mask_${key}`) !== null;
  }

  private listLocalStorageKeys(): string[] {
    const keys: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('zk_mask_')) {
        keys.push(key.substring(8));
      }
    }
    return keys;
  }

  private clearLocalStorage(): void {
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('zk_mask_')) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach(key => localStorage.removeItem(key));
  }

  // Encryption helpers

  private async encryptData(data: Uint8Array): Promise<Uint8Array> {
    if (!this.encryptionKey) return data;

    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      this.encryptionKey,
      data
    );

    const result = new Uint8Array(iv.length + encrypted.byteLength);
    result.set(iv, 0);
    result.set(new Uint8Array(encrypted), iv.length);
    return result;
  }

  private async decryptData(data: Uint8Array): Promise<Uint8Array> {
    if (!this.encryptionKey) return data;

    const iv = data.slice(0, 12);
    const ciphertext = data.slice(12);

    return new Uint8Array(
      await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv },
        this.encryptionKey,
        ciphertext
      )
    );
  }

  private uint8ArrayToBase64(bytes: Uint8Array): string {
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private base64ToUint8Array(base64: string): Uint8Array {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }
}

export { StorageManager };
