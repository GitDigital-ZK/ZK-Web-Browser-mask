/**
 * ZK Web Browser Mask - Verifier Implementation
 * 
 * Server-side verification of zero-knowledge proofs.
 */

import {
  ZKProof,
  VerificationResult,
  ZKVerifierConfig,
  VerificationKey,
  VerificationOptions,
  Constraint,
  PublicSignals,
  ZKError,
  ZKErrorType
} from './types';

interface RevocationRegistry {
  revokedNullifiers: Set<string>;
  lastUpdated: number;
}

/**
 * ZKVerifier - Verify zero-knowledge proofs
 * 
 * This class provides verification functionality for service providers
 * to validate proofs without learning the underlying attributes.
 */
export class ZKVerifier {
  private trustedIssuers: Map<string, VerificationKey>;
  private options: VerificationOptions;
  private revocationRegistry: RevocationRegistry;
  private verificationKey: VerificationKey | null;

  /**
   * Create a new ZKVerifier instance
   */
  constructor(config: ZKVerifierConfig) {
    this.trustedIssuers = config.trustedIssuers || new Map();
    this.verificationKey = config.verificationKey || null;
    this.options = config.options || {
      checkExpiration: true,
      checkNullifier: true,
      allowRevocation: true
    };
    this.revocationRegistry = {
      revokedNullifiers: new Set(),
      lastUpdated: Date.now()
    };
  }

  /**
   * Verify a zero-knowledge proof
   */
  public async verify(
    proof: ZKProof,
    commitment?: { value: Uint8Array }
  ): Promise<VerificationResult> {
    try {
      // Check if proof has expired
      if (this.options.checkExpiration && proof.expiresAt) {
        if (Date.now() > proof.expiresAt) {
          return {
            isValid: false,
            publicSignals: proof.publicSignals,
            nullifier: this.bytesToHex(proof.nullifier),
            error: 'Proof has expired'
          };
        }
      }

      // Check maximum proof age
      if (this.options.maxProofAge) {
        const age = Date.now() - proof.createdAt;
        if (age > this.options.maxProofAge) {
          return {
            isValid: false,
            publicSignals: proof.publicSignals,
            nullifier: this.bytesToHex(proof.nullifier),
            error: 'Proof is too old'
          };
        }
      }

      // Check nullifier revocation
      if (this.options.checkNullifier && this.options.allowRevocation) {
        const nullifierHex = this.bytesToHex(proof.nullifier);
        if (this.revocationRegistry.revokedNullifiers.has(nullifierHex)) {
          return {
            isValid: false,
            publicSignals: proof.publicSignals,
            nullifier: nullifierHex,
            error: 'Nullifier has been revoked'
          };
        }
      }

      // Check trusted issuer
      if (proof.issuer && this.trustedIssuers.size > 0) {
        if (!this.trustedIssuers.has(proof.issuer)) {
          return {
            isValid: false,
            publicSignals: proof.publicSignals,
            nullifier: this.bytesToHex(proof.nullifier),
            error: `Issuer "${proof.issuer}" is not trusted`
          };
        }
      }

      // Verify audience if required
      if (this.options.requireAudience && this.options.allowedAudiences) {
        const audience = proof.publicSignals.audience as string | undefined;
        if (!audience || !this.options.allowedAudiences.includes(audience)) {
          return {
            isValid: false,
            publicSignals: proof.publicSignals,
            nullifier: this.bytesToHex(proof.nullifier),
            error: 'Invalid audience'
          };
        }
      }

      // Verify constraints
      const constraintVerification = await this.verifyConstraints(
        proof.constraints,
        proof.publicSignals
      );

      if (!constraintVerification.valid) {
        return {
          isValid: false,
          publicSignals: proof.publicSignals,
          nullifier: this.bytesToHex(proof.nullifier),
          failedConstraints: constraintVerification.failed,
          error: 'Constraint verification failed'
        };
      }

      // Verify the cryptographic proof
      if (this.verificationKey) {
        const cryptoValid = await this.verifyCryptoProof(
          proof.proofData,
          proof.publicSignals
        );

        if (!cryptoValid) {
          return {
            isValid: false,
            publicSignals: proof.publicSignals,
            nullifier: this.bytesToHex(proof.nullifier),
            error: 'Cryptographic verification failed'
          };
        }
      }

      // All checks passed
      return {
        isValid: true,
        publicSignals: proof.publicSignals,
        nullifier: this.bytesToHex(proof.nullifier),
        metadata: {
          verifiedAt: Date.now(),
          issuer: proof.issuer,
          proofType: proof.proofType
        }
      };
    } catch (error) {
      return {
        isValid: false,
        publicSignals: proof.publicSignals,
        nullifier: this.bytesToHex(proof.nullifier),
        error: `Verification error: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }

  /**
   * Verify multiple proofs in batch
   */
  public async batchVerify(proofs: ZKProof[]): Promise<VerificationResult[]> {
    const results: VerificationResult[] = [];
    
    for (const proof of proofs) {
      const result = await this.verify(proof);
      results.push(result);
    }
    
    return results;
  }

  /**
   * Add a trusted issuer
   */
  public addTrustedIssuer(id: string, key: VerificationKey): void {
    this.trustedIssuers.set(id, key);
  }

  /**
   * Remove a trusted issuer
   */
  public removeTrustedIssuer(id: string): boolean {
    return this.trustedIssuers.delete(id);
  }

  /**
   * Check if an issuer is trusted
   */
  public isTrustedIssuer(issuerId: string): boolean {
    return this.trustedIssuers.has(issuerId);
  }

  /**
   * Revoke a nullifier
   */
  public revokeNullifier(nullifier: string): void {
    this.revocationRegistry.revokedNullifiers.add(nullifier);
    this.revocationRegistry.lastUpdated = Date.now();
  }

  /**
   * Check if a nullifier is revoked
   */
  public isRevoked(nullifier: string): boolean {
    return this.revocationRegistry.revokedNullifiers.has(nullifier);
  }

  /**
   * Load revocation list from a registry
   */
  public async loadRevocationList(url: string): Promise<void> {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Failed to load revocation list: ${response.statusText}`);
      }
      
      const data = await response.json();
      this.revocationRegistry.revokedNullifiers = new Set(data.revoked || []);
      this.revocationRegistry.lastUpdated = Date.now();
    } catch (error) {
      throw new ZKError(
        ZKErrorType.NETWORK_ERROR,
        `Failed to load revocation list: ${error instanceof Error ? error.message : 'Unknown error'}`
      );
    }
  }

  /**
   * Get list of trusted issuers
   */
  public getTrustedIssuers(): string[] {
    return Array.from(this.trustedIssuers.keys());
  }

  /**
   * Get revocation registry info
   */
  public getRevocationInfo(): { count: number; lastUpdated: number } {
    return {
      count: this.revocationRegistry.revokedNullifiers.size,
      lastUpdated: this.revocationRegistry.lastUpdated
    };
  }

  // Private helper methods

  private async verifyConstraints(
    constraints: Constraint[],
    publicSignals: PublicSignals
  ): Promise<{ valid: boolean; failed?: Constraint[] }> {
    const failed: Constraint[] = [];

    for (const constraint of constraints) {
      const signalKey = `constraint_${constraint.attribute}_${constraint.operator}`;
      const signalValue = publicSignals[signalKey];

      if (signalValue === undefined) {
        failed.push(constraint);
        continue;
      }

      const satisfied = this.evaluateConstraint(constraint, signalValue);
      if (!satisfied) {
        failed.push(constraint);
      }
    }

    return {
      valid: failed.length === 0,
      failed: failed.length > 0 ? failed : undefined
    };
  }

  private evaluateConstraint(constraint: Constraint, signalValue: unknown): boolean {
    const expected = constraint.value;

    switch (constraint.operator) {
      case '==':
        return signalValue === expected;
      case '!=':
        return signalValue !== expected;
      case '>':
        return (signalValue as number) > (expected as number);
      case '<':
        return (signalValue as number) < (expected as number);
      case '>=':
        return (signalValue as number) >= (expected as number);
      case '<=':
        return (signalValue as number) <= (expected as number);
      case 'in':
        return Array.isArray(expected) && expected.includes(signalValue);
      case 'notIn':
        return Array.isArray(expected) && !expected.includes(signalValue);
      default:
        return false;
    }
  }

  private async verifyCryptoProof(
    proofData: Uint8Array,
    publicSignals: PublicSignals
  ): Promise<boolean> {
    // In a full implementation, this would use snarkjs or similar
    // to verify the Groth16/PLONK proof cryptographically
    
    // For now, we do a basic check that the proof data is present
    if (!proofData || proofData.length === 0) {
      return false;
    }

    // Verify proof structure
    const expectedMinLength = 128; // Groth16 proof minimum size
    if (proofData.length < expectedMinLength) {
      return false;
    }

    // Verify public signals contain commitment and nullifier
    if (!publicSignals.commitment || !publicSignals.nullifier) {
      return false;
    }

    return true;
  }

  private bytesToHex(bytes: Uint8Array): string {
    return Array.from(bytes)
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }
}

export { ZKVerifier };
