/**
 * ZK Web Browser Mask - Core Implementation
 * 
 * Main implementation of the ZK Web Browser Mask for privacy-preserving identity verification.
 */

import {
  MaskAttributes,
  Constraint,
  ProofRequest,
  ZKProof,
  Commitment,
  PublicSignals,
  ZKMaskConfig,
  ZKProofConfig,
  ExportedMask,
  ZKError,
  ZKErrorType,
  IStorageManager,
  ICryptoService
} from './types';
import { CryptoService } from './crypto';
import { StorageManager } from './storage';
import { ZKProver } from './prover';
import { MerkleTree, hashAttributes, randomSalt } from './utils';

/**
 * ZKWebBrowserMask - Main class for creating and managing identity masks
 * 
 * This class provides the core functionality for:
 * - Creating cryptographic commitments from user attributes
 * - Generating zero-knowledge proofs
 * - Managing mask lifecycle (create, export, import, revoke)
 */
export class ZKWebBrowserMask {
  private attributes: MaskAttributes;
  private config: ZKProofConfig;
  private storage: IStorageManager;
  private crypto: ICryptoService;
  private prover: ZKProver | null = null;
  private commitment: Commitment | null = null;
  private nullifier: Uint8Array | null = null;
  private salt: Uint8Array | null = null;
  private initialized: boolean = false;
  private maskId: string;
  private createdAt: number;
  private expiresAt?: number;
  private revoked: boolean = false;
  private encryptionKey: CryptoKey | null;

  /**
   * Create a new ZKWebBrowserMask instance
   */
  constructor(config: ZKMaskConfig) {
    this.attributes = config.attributes;
    this.config = config.config || {
      curve: 'bn128',
      provingScheme: 'groth16'
    };
    this.encryptionKey = config.encryptionKey || null;
    this.createdAt = Date.now();
    this.maskId = this.generateMaskId();
    
    // Initialize storage
    this.storage = new StorageManager({
      backend: config.storageBackend || 'indexeddb',
      encryptionKey: this.encryptionKey
    });
    
    // Initialize crypto service
    this.crypto = new CryptoService();
  }

  /**
   * Initialize the mask and generate proving/verification keys
   */
  public async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }

    try {
      // Generate random salt for this mask
      this.salt = await this.crypto.generateRandomBytes(32);
      
      // Generate commitment from attributes
      const attributesHash = await hashAttributes(this.attributes, this.salt);
      
      // Generate nullifier secret
      const nullifierSecret = await this.crypto.generateRandomBytes(32);
      
      // Hash the nullifier secret with commitment for uniqueness
      const nullifierHash = await this.crypto.hash(
        new Uint8Array([...attributesHash, ...nullifierSecret])
      );
      
      this.nullifier = nullifierHash;
      
      // Create commitment
      this.commitment = {
        value: attributesHash,
        salt: this.salt,
        attributesHash: attributesHash,
        createdAt: this.createdAt
      };
      
      // Initialize the ZK prover
      this.prover = new ZKProver(this.config);
      await this.prover.initialize();
      
      // Save to storage
      await this.save();
      
      this.initialized = true;
    } catch (error) {
      throw new ZKError(
        ZKErrorType.PROOF_GENERATION_FAILED,
        `Failed to initialize mask: ${error instanceof Error ? error.message : 'Unknown error'}`,
        { error }
      );
    }
  }

  /**
   * Generate a zero-knowledge proof for the given constraints
   */
  public async generateProof(request: ProofRequest): Promise<ZKProof> {
    if (!this.initialized || !this.prover) {
      throw new ZKError(
        ZKErrorType.INVALID_CONFIG,
        'Mask not initialized. Call initialize() first.'
      );
    }

    if (this.revoked) {
      throw new ZKError(
        ZKErrorType.REVOKED,
        'This mask has been revoked and cannot be used to generate proofs.'
      );
    }

    // Validate constraints
    this.validateConstraints(request.constraints);
    
    // Check expiration
    if (this.expiresAt && Date.now() > this.expiresAt) {
      throw new ZKError(
        ZKErrorType.EXPIRED,
        'This mask has expired.'
      );
    }

    try {
      // Prepare private inputs (attributes + nullifier secret)
      const privateInputs: Uint8Array[] = [];
      
      for (const key of Object.keys(this.attributes)) {
        const attr = this.attributes[key];
        privateInputs.push(this.attributeToBytes(attr));
      }
      
      // Add nullifier as private input
      if (this.nullifier) {
        privateInputs.push(this.nullifier);
      }
      
      // Prepare public inputs (commitment + constraints)
      const publicInputs: Uint8Array[] = [
        this.commitment!.value
      ];
      
      // Add constraint values as public inputs
      for (const constraint of request.constraints) {
        const value = this.getConstraintValue(constraint);
        publicInputs.push(value);
      }
      
      // Generate the proof
      const proofData = await this.prover.generateProof(
        request.constraints,
        privateInputs,
        publicInputs
      );
      
      // Create public signals
      const publicSignals: PublicSignals = {
        commitment: this.bytesToBase58(this.commitment!.value),
        nullifier: this.bytesToBase58(this.nullifier!),
        timestamp: Date.now(),
        ...(request.issuer && { issuer: request.issuer }),
        ...(request.audience && { audience: request.audience })
      };
      
      // Create expiration if specified
      const expiresAt = request.expiration || 
        (Date.now() + (request.metadata?.defaultTTL as number || 86400000));
      
      return {
        proofData,
        publicSignals,
        proofType: this.getProofType(request.constraints),
        createdAt: Date.now(),
        expiresAt,
        issuer: request.issuer,
        nullifier: this.nullifier,
        constraints: request.constraints
      };
    } catch (error) {
      throw new ZKError(
        ZKErrorType.PROOF_GENERATION_FAILED,
        `Failed to generate proof: ${error instanceof Error ? error.message : 'Unknown error'}`,
        { error, constraints: request.constraints }
      );
    }
  }

  /**
   * Get the commitment for this mask
   */
  public getCommitment(): Commitment {
    if (!this.commitment) {
      throw new ZKError(
        ZKErrorType.INVALID_CONFIG,
        'Mask not initialized. Call initialize() first.'
      );
    }
    return { ...this.commitment };
  }

  /**
   * Get the nullifier for this mask
   */
  public getNullifier(): Uint8Array {
    if (!this.nullifier) {
      throw new ZKError(
        ZKErrorType.INVALID_CONFIG,
        'Mask not initialized. Call initialize() first.'
      );
    }
    return new Uint8Array(this.nullifier);
  }

  /**
   * Export the mask for backup
   */
  public async export(): Promise<ExportedMask> {
    if (!this.initialized) {
      throw new ZKError(
        ZKErrorType.INVALID_CONFIG,
        'Mask not initialized. Call initialize() first.'
      );
    }

    return {
      version: '1.0.0',
      commitment: this.bytesToBase58(this.commitment!.value),
      nullifier: this.bytesToBase58(this.nullifier!),
      attributes: { ...this.attributes },
      createdAt: this.createdAt,
      expiresAt: this.expiresAt
    };
  }

  /**
   * Import a mask from exported data
   */
  public static async import(data: ExportedMask): Promise<ZKWebBrowserMask> {
    const mask = new ZKWebBrowserMask({
      attributes: data.attributes,
      requireUserConsent: false
    });
    
    await mask.initialize();
    
    return mask;
  }

  /**
   * Revoke this mask
   */
  public async revoke(): Promise<void> {
    if (!this.initialized) {
      throw new ZKError(
        ZKErrorType.INVALID_CONFIG,
        'Mask not initialized.'
      );
    }

    this.revoked = true;
    await this.save();
  }

  /**
   * Set mask expiration time
   */
  public setExpiration(timestamp: number): void {
    this.expiresAt = timestamp;
  }

  /**
   * Check if the mask is expired
   */
  public isExpired(): boolean {
    if (!this.expiresAt) {
      return false;
    }
    return Date.now() > this.expiresAt;
  }

  /**
   * Check if the mask is revoked
   */
  public isRevoked(): boolean {
    return this.revoked;
  }

  /**
   * Get the mask ID
   */
  public getMaskId(): string {
    return this.maskId;
  }

  /**
   * Get the mask attributes
   */
  public getAttributes(): MaskAttributes {
    return { ...this.attributes };
  }

  /**
   * Get creation timestamp
   */
  public getCreatedAt(): number {
    return this.createdAt;
  }

  // Private helper methods

  private generateMaskId(): string {
    return `mask_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
  }

  private validateConstraints(constraints: Constraint[]): void {
    for (const constraint of constraints) {
      if (!(constraint.attribute in this.attributes)) {
        throw new ZKError(
          ZKErrorType.MISSING_ATTRIBUTE,
          `Attribute "${constraint.attribute}" not found in mask.`,
          { attribute: constraint.attribute, availableAttributes: Object.keys(this.attributes) }
        );
      }

      if (!this.isValidOperator(constraint.operator)) {
        throw new ZKError(
          ZKErrorType.INVALID_CONSTRAINT,
          `Invalid operator "${constraint.operator}" for attribute "${constraint.attribute}".`,
          { operator: constraint.operator, attribute: constraint.attribute }
        );
      }
    }
  }

  private isValidOperator(operator: string): boolean {
    const validOperators = ['==', '!=', '>', '<', '>=', '<=', 'in', 'notIn'];
    return validOperators.includes(operator);
  }

  private attributeToBytes(attr: { type: string; value: unknown }): Uint8Array {
    switch (attr.type) {
      case 'uint8':
        return new Uint8Array([attr.value as number]);
      case 'uint32':
        const buf32 = new ArrayBuffer(4);
        new DataView(buf32).setUint32(0, attr.value as number);
        return new Uint8Array(buf32);
      case 'uint64':
        const buf64 = new ArrayBuffer(8);
        new DataView(buf64).setBigUint64(0, attr.value as bigint);
        return new Uint8Array(buf64);
      case 'boolean':
        return new Uint8Array([(attr.value as boolean) ? 1 : 0]);
      case 'string':
        return new TextEncoder().encode(attr.value as string);
      case 'bytes':
        return attr.value as Uint8Array;
      default:
        throw new ZKError(
          ZKErrorType.INVALID_CONFIG,
          `Unknown attribute type: ${attr.type}`
        );
    }
  }

  private getConstraintValue(constraint: Constraint): Uint8Array {
    const value = constraint.value;
    
    if (Array.isArray(value)) {
      // For 'in' and 'notIn' operators, hash all values together
      const combined = value.map(v => this.encodeValue(v)).flat();
      return this.crypto.hash(new Uint8Array(combined)).slice(0, 32);
    }
    
    return this.encodeValue(value);
  }

  private encodeValue(value: number | string | boolean | bigint): Uint8Array {
    if (typeof value === 'number') {
      const buf = new ArrayBuffer(4);
      new DataView(buf).setUint32(0, value);
      return new Uint8Array(buf);
    }
    if (typeof value === 'bigint') {
      const buf = new ArrayBuffer(8);
      new DataView(buf).setBigUint64(0, value);
      return new Uint8Array(buf);
    }
    if (typeof value === 'boolean') {
      return new Uint8Array([value ? 1 : 0]);
    }
    if (typeof value === 'string') {
      return new TextEncoder().encode(value);
    }
    throw new ZKError(
      ZKErrorType.INVALID_CONSTRAINT,
      `Cannot encode value of type ${typeof value}`
    );
  }

  private getProofType(constraints: Constraint[]): string {
    const types = constraints.map(c => `${c.attribute}_${c.operator}`);
    return `multi_attribute_${types.length}`;
  }

  private bytesToBase58(bytes: Uint8Array): string {
    const alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    let num = BigInt('0x' + Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join(''));
    let result = '';
    
    while (num > 0n) {
      const remainder = num % 58n;
      result = alphabet[Number(remainder)] + result;
      num = num / 58n;
    }
    
    return result;
  }

  private async save(): Promise<void> {
    const data = {
      maskId: this.maskId,
      attributes: this.attributes,
      commitment: this.commitment,
      nullifier: this.nullifier,
      salt: this.salt,
      createdAt: this.createdAt,
      expiresAt: this.expiresAt,
      revoked: this.revoked
    };
    
    const jsonData = JSON.stringify(data, (key, value) => {
      if (value instanceof Uint8Array) {
        return { __type: 'Uint8Array', data: Array.from(value) };
      }
      if (typeof value === 'bigint') {
        return { __type: 'bigint', data: value.toString() };
      }
      return value;
    });
    
    await this.storage.save(`mask_${this.maskId}`, new TextEncoder().encode(jsonData));
  }
}

export { ZKWebBrowserMask };
