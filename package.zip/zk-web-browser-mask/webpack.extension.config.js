/**
 * Webpack configuration for browser extension
 * 
 * Builds the extension with proper module resolution and optimization.
 */

const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
  mode: process.env.NODE_ENV === 'production' ? 'production' : 'development',
  entry: {
    background: './extension/background/background.js',
    popup: './extension/popup/popup.js',
    content: './extension/content/content.js',
    provider: './extension/provider/provider.js',
  },
  output: {
    path: path.resolve(__dirname, 'extension/dist'),
    filename: '[name]/[name].js',
    clean: true,
  },
  module: {
    rules: [
      {
        test: /\.ts$/,
        use: 'ts-loader',
        exclude: /node_modules/,
      },
      {
        test: /\.js$/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              ['@babel/preset-env', { targets: { chrome: '100', firefox: '109' } }],
            ],
          },
        },
        exclude: /node_modules/,
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      },
      {
        test: /\.(png|jpg|gif|svg|ico)$/,
        type: 'asset/resource',
        generator: {
          filename: 'icons/[name][ext]',
        },
      },
      {
        test: /\.(woff|woff2|eot|ttf|otf)$/,
        type: 'asset/resource',
        generator: {
          filename: 'fonts/[name][ext]',
        },
      },
      {
        test: /\.html$/,
        use: 'html-loader',
        exclude: /node_modules/,
      },
    ],
  },
  resolve: {
    extensions: ['.js', '.ts', '.json'],
    alias: {
      '@sdk': path.resolve(__dirname, 'src/sdk'),
      '@extension': path.resolve(__dirname, 'extension'),
    },
  },
  plugins: [
    new CopyWebpackPlugin({
      patterns: [
        {
          from: 'extension/manifest.json',
          to: 'manifest.json',
        },
        {
          from: 'extension/popup/popup.html',
          to: 'popup/popup.html',
        },
        {
          from: 'extension/icons',
          to: 'icons',
        },
        {
          from: 'extension/content/content.css',
          to: 'content/content.css',
        },
      ],
    }),
  ],
  optimization: {
    minimize: process.env.NODE_ENV === 'production',
    splitChunks: {
      chunks: 'all',
      cacheGroups: {
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          name: 'vendors',
          chunks: 'all',
        },
      },
    },
  },
  devtool: process.env.NODE_ENV === 'production' 
    ? 'source-map' 
    : 'eval-source-map',
  target: 'web',
  devServer: {
    static: {
      directory: path.join(__dirname, 'extension/dist'),
    },
    port: 3000,
    hot: true,
    open: true,
  },
};
