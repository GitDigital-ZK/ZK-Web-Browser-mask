# ZK Web Browser Mask

**Privacy-Preserving Identity Verification for the Web**

ZK Web Browser Mask is an open-source implementation of zero-knowledge proof (ZKP) technology that enables users to verify their identity attributes (age, nationality, membership, etc.) without revealing the underlying personal data. Built for the web platform, it provides seamless integration for applications requiring compliance without compromising user privacy.

## Key Features

| Feature | Description |
|---------|-------------|
| **Zero-Knowledge Proofs** | Prove predicates like "age >= 18" or "country in allowed list" without exposing raw data |
| **Web-Native** | TypeScript SDK designed for modern web applications |
| **Browser Mask** | Privacy-preserving browser extension framework for identity verification |
| **Multi-Platform** | Supports web browsers, Node.js, and server-side verification |
| **Standards-Based** | Compatible with W3C DID and Verifiable Credentials standards |
| **Compliance-Ready** | Designed for KYC/AML requirements without killing user experience |

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Architecture](#architecture)
- [SDK Reference](#sdk-reference)
- [Browser Extension](#browser-extension)
- [Examples](#examples)
- [API Reference](#api-reference)
- [Security](#security)
- [Contributing](#contributing)
- [License](#license)

## Installation

### Browser Extension (End Users)

1. Clone the repository:
```bash
git clone https://github.com/your-org/zk-web-browser-mask.git
cd zk-web-browser-mask
```

2. Build the extension:
```bash
npm install
npm run build:extension
```

3. Load in browser:
   - Chrome: Go to `chrome://extensions/`, enable "Developer mode", click "Load unpacked", select `dist/extension/`
   - Firefox: Go to `about:debugging#/runtime/this-firefox`, click "Load Temporary Add-on", select `dist/extension/manifest.json`

### SDK (Developers)

```bash
npm install zk-web-browser-mask-sdk
```

Or install from source:

```bash
npm install
npm run build:sdk
```

## Quick Start

### Creating a Mask (User Side)

```typescript
import { ZKWebBrowserMask, MaskAttributes } from 'zk-web-browser-mask-sdk';

// Initialize the mask with user attributes
const mask = new ZKWebBrowserMask({
  age: 25,
  country: 'US',
  isVerified: true,
  membershipTier: 'premium'
});

// Generate a commitment (this is what gets stored on-chain or with service providers)
const commitment = await mask.createCommitment();

console.log('Commitment:', commitment.toBase58());
// Output: Commitment: 7nKxL9mW4YfBbA8VcQXs...
```

### Generating a Proof (User Side)

```typescript
// Prove that user is 18 or older without revealing exact age
const proofRequest = {
  predicate: 'age >= 18',
  issuer: 'trusted-kyc-provider',
  timestamp: Date.now(),
  nonce: crypto.getRandomValues(new Uint8Array(16))
};

const proof = await mask.generateProof(proofRequest);

console.log('Proof generated:', proof.proofType);
// Output: Proof generated: age_verification
```

### Verifying a Proof (Service Provider Side)

```typescript
import { ZKVerifier } from 'zk-web-browser-mask-sdk';

// Initialize verifier with trusted issuers
const verifier = new ZKVerifier({
  trustedIssuers: ['trusted-kyc-provider', 'government-agency'],
  requireTimestamp: true,
  maxAge: 86400000 // 24 hours
});

// Verify the proof
const verificationResult = await verifier.verify(proof, commitment);

if (verificationResult.isValid) {
  console.log('Verification successful!');
  console.log('Revealed attributes:', verificationResult.revealedAttributes);
} else {
  console.log('Verification failed:', verificationResult.error);
}
```

## Architecture

### System Overview

The ZK Web Browser Mask system consists of three main components:

```
┌─────────────────────────────────────────────────────────────────┐
│                        User Browser                              │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────┐    │
│  │   Mask UI   │  │  ZK Prover   │  │  Attribute Storage  │    │
│  └─────────────┘  └──────────────┘  └─────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ ZK Proof
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Service Provider                            │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────┐    │
│  │  Verifier  │  │  Commitment  │  │   Compliance Engine │    │
│  │    API     │  │   Registry   │  │                     │    │
│  └─────────────┘  └──────────────┘  └─────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### Component Descriptions

| Component | Description | Technology |
|-----------|-------------|------------|
| Mask UI | User interface for managing identity masks | TypeScript, HTML/CSS |
| ZK Prover | Generates zero-knowledge proofs | TypeScript, WASM |
| Attribute Storage | Secure storage for user attributes | IndexedDB, WebCrypto |
| Verifier API | Server-side proof verification | Node.js, TypeScript |
| Commitment Registry | Stores commitments for verification | Various backends |
| Compliance Engine | Enforces business logic | TypeScript |

### Technology Stack

- **Core ZK**: Groth16 proofs with circom-compatible constraints
- **WebAssembly**: High-performance ZK operations in browser
- **TypeScript**: Type-safe SDK for web integration
- **Node.js**: Server-side verification and SDK support
- **WebCrypto API**: Secure cryptographic operations
- **IndexedDB**: Client-side secure storage

## SDK Reference

### Installation

```bash
npm install zk-web-browser-mask-sdk
```

### Basic Usage

```typescript
import { 
  ZKWebBrowserMask,      // Main class for creating masks
  MaskAttributes,         // Type definitions for attributes
  ZKProof,               // Proof generation/verification types
  ZKVerifier,            // Verification class
  Commitment,            // Commitment types
  ProofRequest,          // Proof request configuration
  VerificationResult     // Verification result type
} from 'zk-web-browser-mask-sdk';
```

### Configuration Options

```typescript
interface ZKMaskConfig {
  // Circuit parameters
  curve: 'bn128' | 'bls12_381';
  provingScheme: 'groth16' | 'plonk';
  
  // Storage configuration
  storageBackend: 'indexeddb' | 'localStorage' | 'memory';
  encryptionKey: CryptoKey | null;
  
  // Network configuration
  rpcEndpoint: string;
  commitmentRegistry: string;
  
  // Security options
  requireUserConsent: boolean;
  auditLogging: boolean;
}
```

### Mask Creation

```typescript
const mask = new ZKWebBrowserMask({
  // Define attributes with types
  attributes: {
    age: { type: 'uint8', value: 25 },
    country: { type: 'string', value: 'US' },
    kycVerified: { type: 'boolean', value: true },
    accountAge: { type: 'uint32', value: 365 }
  },
  
  // Configure proof generation
  config: {
    curve: 'bn128',
    provingScheme: 'groth16'
  }
});

// Initialize the mask (generates proving/verification keys)
await mask.initialize();

// Export the commitment for registration
const commitment = mask.getCommitment();
const nullifier = mask.getNullifier();
```

### Proof Generation

```typescript
// Define what you want to prove
const proofRequest: ProofRequest = {
  constraints: [
    { attribute: 'age', operator: '>=', value: 18 },
    { attribute: 'kycVerified', operator: '==', value: true },
    { attribute: 'country', operator: 'in', values: ['US', 'CA', 'UK'] }
  ],
  
  // Proof metadata
  issuer: 'my-kyc-provider',
  audience: 'my-dapp',
  expiration: Date.now() + 86400000, // 24 hours
  nonce: await crypto.subtle.generateKey('AES-GCM', 256, true)
};

// Generate the zero-knowledge proof
const proof = await mask.generateProof(proofRequest);

// Export proof for transmission
const proofData = proof.export();
```

### Proof Verification

```typescript
const verifier = new ZKVerifier({
  // Trusted issuers (their verification keys are known)
  trustedIssuers: new Map([
    ['my-kyc-provider', issuerVerificationKey],
    ['government-agency', govVerificationKey]
  ]),
  
  // Verification options
  options: {
    checkExpiration: true,
    maxProofAge: 86400000,
    checkNullifier: true,
    allowRevocation: true
  }
});

// Verify a proof
const result = await verifier.verify(proof, commitment);

if (result.isValid) {
  console.log('Proof verified successfully');
  console.log('Revealed attributes:', result.publicSignals);
  console.log('Nullifier:', result.nullifier);
} else {
  console.log('Verification failed:', result.error);
  console.log('Failed constraints:', result.failedConstraints);
}
```

## Browser Extension

### Extension Architecture

The browser extension provides a user-friendly interface for managing identity masks and generating proofs directly from the browser.

```
┌─────────────────────────────────────────────────────────────────┐
│                     Browser Extension                            │
│  ┌───────────────┐  ┌──────────────┐  ┌────────────────────┐   │
│  │  Popup UI     │  │  Background  │  │  Content Scripts   │   │
│  │  (React)      │  │  Service     │  │                    │   │
│  └───────────────┘  └──────────────┘  └────────────────────┘   │
│         │                  │                    │                │
│         ▼                  ▼                    ▼                │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   ZK Web Browser Mask SDK               │    │
│  │  ┌─────────┐  ┌──────────┐  ┌─────────┐  ┌──────────┐  │    │
│  │  │ Mask    │  │ Proof    │  │ Storage │  │ Crypto   │  │    │
│  │  │ Manager │  │ Generator│  │ Manager │  │ Service  │  │    │
│  │  └─────────┘  └──────────┘  └─────────┘  └──────────┘  │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### Extension Features

| Feature | Description |
|---------|-------------|
| **Mask Dashboard** | View and manage all identity masks |
| **One-Click Proof** | Generate proofs with a single click |
| **Visual Privacy Indicators** | See what data is being revealed |
| **Domain Verification** | Verify which domains can request proofs |
| **Audit Log** | Track all proof generations and verifications |
| **Secure Storage** | Encrypted local storage for sensitive data |

### Extension API

```typescript
// Content script API
interface ZKBrowserAPI {
  // Check if user has a valid mask
  hasMask(domain: string): Promise<boolean>;
  
  // Request proof from user
  requestProof(request: ProofRequest): Promise<ZKProof>;
  
  // Get user's masks for a domain
  getMasks(domain: string): Promise<Mask[]>;
  
  // Register a new mask
  registerMask(attributes: MaskAttributes): Promise<Commitment>;
}

// Usage in web page
const zkAPI = window.zkBrowserAPI;

// Request proof from extension
const proof = await zkAPI.requestProof({
  constraints: [{ attribute: 'age', operator: '>=', value: 18 }],
  domain: 'my-dapp.com',
  reason: 'Age verification for content access'
});
```

## Examples

### Age Verification Gate

Complete example of implementing age-restricted content access:

```typescript
// server.ts - Service Provider Side
import { ZKVerifier, VerificationResult } from 'zk-web-browser-mask-sdk';
import express from 'express';

const app = express();
const verifier = new ZKVerifier({
  trustedIssuers: loadTrustedIssuers(),
  options: {
    checkExpiration: true,
    maxProofAge: 3600000 // 1 hour
  }
});

app.post('/api/verify-age', async (req, res) => {
  try {
    const { proof, commitment } = req.body;
    
    const result = await verifier.verify(proof, commitment, {
      constraints: [
        { attribute: 'age', operator: '>=', value: 21 },
        { attribute: 'kycProvider', operator: 'in', 
          values: ['gov-id', 'passport-authority'] }
      ]
    });
    
    if (result.isValid) {
      // Set secure session cookie
      res.cookie('age_verified', result.nullifier, {
        secure: true,
        httpOnly: true,
        maxAge: 3600000
      });
      
      res.json({ 
        success: true, 
        accessLevel: 'adult',
        expiresIn: 3600
      });
    } else {
      res.status(403).json({ 
        success: false, 
        reason: 'Age verification failed',
        canRetry: true
      });
    }
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      reason: 'Verification error' 
    });
  }
});

app.listen(3000);
```

```typescript
// client.ts - User Side
import { ZKWebBrowserMask } from 'zk-web-browser-mask-sdk';

class AgeGate {
  private mask: ZKWebBrowserMask;
  
  constructor() {
    this.mask = new ZKWebBrowserMask({
      attributes: {
        age: { type: 'uint8', value: 25 },
        kycProvider: { type: 'string', value: 'gov-id' }
      }
    });
  }
  
  async verify(): Promise<boolean> {
    // Check if already verified in session
    if (document.cookie.includes('age_verified=')) {
      return true;
    }
    
    // Request verification
    const response = await fetch('/api/verify-age', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        proof: await this.mask.generateProof({
          constraints: [
            { attribute: 'age', operator: '>=', value: 21 }
          ]
        }),
        commitment: this.mask.getCommitment()
      })
    });
    
    const result = await response.json();
    return result.success;
  }
}

// Usage
const gate = new AgeGate();
const verified = await gate.verify();

if (verified) {
  document.getElementById('content').style.display = 'block';
} else {
  document.getElementById('age-gate').style.display = 'block';
}
```

### Membership Verification

Verify user membership tier without revealing account details:

```typescript
import { ZKWebBrowserMask, ZKVerifier } from 'zk-web-browser-mask-sdk';

// User Side - Create membership mask
const membershipMask = new ZKWebBrowserMask({
  attributes: {
    tier: { type: 'uint8', value: 3 }, // 1=basic, 2=premium, 3=enterprise
    subscriptionActive: { type: 'boolean', value: true },
    memberSince: { type: 'uint32', value: 1577836800 }
  }
});

// Generate proof for premium features
const premiumProof = await membershipMask.generateProof({
  constraints: [
    { attribute: 'tier', operator: '>=', value: 2 },
    { attribute: 'subscriptionActive', operator: '==', value: true }
  ],
  metadata: {
    feature: 'premium-content',
    planRequired: 'premium'
  }
});

// Service Provider Side - Verify membership
const membershipVerifier = new ZKVerifier({
  trustedIssuers: ['membership-authority'],
  options: { checkNullifier: true }
});

const verification = await membershipVerifier.verify(premiumProof);

if (verification.isValid && verification.publicSignals.tier >= 2) {
  // Grant premium access
  await grantPremiumAccess(verification.nullifier);
}
```

### Multi-Attribute Proof

Combine multiple attributes in a single proof:

```typescript
// Comprehensive identity proof
const comprehensiveProof = await mask.generateProof({
  constraints: [
    // Age constraints
    { attribute: 'age', operator: '>=', value: 18 },
    { attribute: 'age', operator: '<=', value: 100 },
    
    // Geographic constraints
    { attribute: 'country', operator: 'in', 
      values: ['US', 'CA', 'UK', 'AU', 'DE'] },
    
    // Status constraints
    { attribute: 'isVerified', operator: '==', value: true },
    { attribute: 'isNotSanctioned', operator: '==', value: true },
    
    // Account constraints
    { attribute: 'accountAge', operator: '>=', value: 30 }
  ],
  
  // Circuit configuration
  circuit: 'comprehensive-identity',
  provingTime: 'balanced' // 'speed' | 'balanced' | 'security'
});

console.log('Proof size:', comprehensiveProof.proofData.byteLength, 'bytes');
console.log('Verification time:', comprehensiveProof.verificationTime, 'ms');
```

## API Reference

### ZKWebBrowserMask Class

#### Constructor

```typescript
new ZKWebBrowserMask(config: ZKMaskConfig): ZKWebBrowserMask
```

#### Methods

| Method | Parameters | Returns | Description |
|--------|------------|---------|-------------|
| `initialize()` | None | `Promise<void>` | Initialize the mask and generate keys |
| `createCommitment()` | None | `Commitment` | Generate a commitment from attributes |
| `generateProof()` | `ProofRequest` | `Promise<ZKProof>` | Generate a zero-knowledge proof |
| `export()` | None | `ExportedMask` | Export mask data for backup |
| `import()` | `ExportedMask` | `Promise<void>` | Import mask data from backup |
| `revoke()` | None | `Promise<void>` | Revoke this mask |
| `getNullifier()` | None | `Uint8Array` | Get the nullifier for this mask |
| `getCommitment()` | None | `Commitment` | Get the commitment for this mask |

### ZKVerifier Class

#### Constructor

```typescript
new ZKVerifier(config: ZKVerifierConfig): ZKVerifier
```

#### Methods

| Method | Parameters | Returns | Description |
|--------|------------|---------|-------------|
| `verify()` | `ZKProof, Commitment` | `Promise<VerificationResult>` | Verify a proof |
| `addTrustedIssuer()` | `string, VerificationKey` | `void` | Add a trusted issuer |
| `removeTrustedIssuer()` | `string` | `void` | Remove a trusted issuer |
| `checkRevocation()` | `Nullifier` | `Promise<boolean>` | Check if a nullifier is revoked |
| `batchVerify()` | `Array<ZKProof>` | `Promise<Array<VerificationResult>>` | Verify multiple proofs |

### Types

```typescript
// Mask Attributes
interface MaskAttributes {
  [key: string]: AttributeValue;
}

type AttributeValue = 
  | { type: 'uint8'; value: number }
  | { type: 'uint32'; value: number }
  | { type: 'uint64'; value: bigint }
  | { type: 'boolean'; value: boolean }
  | { type: 'string'; value: string }
  | { type: 'bytes'; value: Uint8Array };

// Proof Request
interface ProofRequest {
  constraints: Constraint[];
  issuer?: string;
  audience?: string;
  expiration?: number;
  nonce?: Uint8Array;
  metadata?: Record<string, unknown>;
}

interface Constraint {
  attribute: string;
  operator: '==' | '!=' | '>' | '<' | '>=' | '<=' | 'in' | 'notIn';
  value: AttributeValue['value'] | AttributeValue['value'][];
}

// Proof
interface ZKProof {
  proofData: Uint8Array;
  publicSignals: PublicSignals;
  proofType: string;
  createdAt: number;
  expiresAt?: number;
  issuer?: string;
  nullifier: Uint8Array;
}

// Verification Result
interface VerificationResult {
  isValid: boolean;
  publicSignals: PublicSignals;
  nullifier: Uint8Array;
  failedConstraints?: Constraint[];
  error?: string;
  metadata?: Record<string, unknown>;
}
```

## Security

### Security Model

The ZK Web Browser Mask implements multiple layers of security:

| Layer | Protection |
|-------|------------|
| **Cryptographic** | Standardized ZK proofs (Groth16, PLONK) with trusted setup |
| **Storage** | AES-256-GCM encryption for all sensitive data |
| **Transport** | TLS 1.3 required for all network communication |
| **Access Control** | User consent required before any proof generation |
| **Audit** | Complete audit trail of all operations |

### Trusted Setup

The system uses pre-generated proving and verification keys:

```
Ceremony participants: 100+
Security parameter: λ = 128 bits
Contribution method: Multi-party computation (MPC)
```

### Privacy Guarantees

- **Zero Knowledge**: No information beyond proof validity is revealed
- **Unlinkability**: Multiple proofs cannot be linked to the same commitment
- **Selective Disclosure**: Only requested attributes are revealed
- **Revocability**: Issuers can revoke credentials without compromising privacy

### Security Best Practices

1. **For Developers**:
   - Always use HTTPS in production
   - Validate all user inputs
   - Implement rate limiting on verification endpoints
   - Store verification keys securely

2. **For Users**:
   - Use strong authentication for mask management
   - Review proof requests carefully
   - Regularly audit connected applications
   - Revoke unused masks promptly

### Reporting Security Issues

If you discover a security vulnerability, please report it to:

📧 **security@zkwebbrowsermask.org**

Please include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact assessment
- Suggested remediation (if any)

## Contributing

We welcome contributions from the community! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

### Development Setup

```bash
# Clone the repository
git clone https://github.com/your-org/zk-web-browser-mask.git
cd zk-web-browser-mask

# Install dependencies
npm install

# Build the SDK
npm run build:sdk

# Build the extension
npm run build:extension

# Run tests
npm test

# Run linter
npm run lint
```

### Code Style

We use ESLint and Prettier for code formatting:

```bash
# Format code
npm run format

# Check formatting
npm run format:check
```

### Pull Request Process

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

Please ensure all tests pass and your code is properly formatted before submitting.

## Roadmap

| Quarter | Feature |
|---------|---------|
| Q1 2025 | Core ZK proof system (Groth16) |
| Q2 2025 | Browser extension MVP |
| Q3 2025 | PLONK support and performance optimization |
| Q4 2025 | Multi-chain support (Ethereum, Solana) |
| Q1 2026 | Hardware wallet integration |
| Q2 2026 | Decentralized issuer registry |

## Related Projects

- [zk-SNARKs](https://github.com/iden3/gnark) - High-performance ZK library
- [Semaphore](https://github.com/semaphore-protocol/semaphore) - Anonymous signaling
- [Worldcoin](https://github.com/worldcoin/worldcoin-protocol) - Identity and proof of personhood
- [Polygon ID](https://github.com/0xpolygonid/issuer-node) - Self-sovereign identity

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- The [zkSNARK Team](https://github.com/iden3/gnark) for the Groth16 implementation
- [Jwz](https://zkp.org) for the Zero Knowledge Proof community
- [ETHGlobal](https://ethglobal.co) for supporting ZK innovation

## Contact

- **Website**: https://zkwebbrowsermask.org
- **GitHub Issues**: https://github.com/your-org/zk-web-browser-mask/issues
- **Discord**: https://discord.gg/zkwebbrowsermask
- **Twitter**: [@zkwebbrowsermask](https://twitter.com/zkwebbrowsermask)

---

**Built with privacy by design. Verified without compromise.**
