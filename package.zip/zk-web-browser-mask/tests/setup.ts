/**
 * Jest Test Setup
 * 
 * Global test configuration and mocks.
 */

// Mock WebCrypto API for Node.js environment
const mockCrypto = {
  getRandomValues: (array: Uint8Array): Uint8Array => {
    for (let i = 0; i < array.length; i++) {
      array[i] = Math.floor(Math.random() * 256);
    }
    return array;
  },
  subtle: {
    digest: async (algorithm: string, data: BufferSource): Promise<ArrayBuffer> => {
      // Simple mock SHA-256 implementation
      const input = new Uint8Array(data as ArrayBuffer);
      const output = new Uint8Array(32);
      for (let i = 0; i < 32; i++) {
        output[i] = (input[i % input.length] + i) % 256;
      }
      return output.buffer;
    },
    generateKey: async (
      algorithm: AlgorithmIdentifier | AesKeyGenParams,
      extractable: boolean,
      keyUsages: KeyUsage[]
    ): Promise<CryptoKey> => {
      return {
        type: 'secret',
        algorithm: algorithm as Algorithm,
        extractable,
        usages: new Set(keyUsages),
      } as CryptoKey;
    },
    encrypt: async (
      algorithm: AlgorithmIdentifier | AesKeyAlgorithm,
      key: CryptoKey,
      data: BufferSource
    ): Promise<ArrayBuffer> => {
      const input = new Uint8Array(data as ArrayBuffer);
      const output = new Uint8Array(input.length + 12);
      // Add mock IV
      for (let i = 0; i < 12; i++) {
        output[i] = i;
      }
      // Copy data
      for (let i = 0; i < input.length; i++) {
        output[i + 12] = input[i];
      }
      return output.buffer;
    },
    decrypt: async (
      algorithm: AlgorithmIdentifier | AesKeyAlgorithm,
      key: CryptoKey,
      data: BufferSource
    ): Promise<ArrayBuffer> => {
      const input = new Uint8Array(data as ArrayBuffer);
      // Remove IV and return data
      const output = new Uint8Array(input.length - 12);
      for (let i = 0; i < output.length; i++) {
        output[i] = input[i + 12];
      }
      return output.buffer;
    },
    importKey: async (
      format: KeyFormat,
      keyData: BufferSource,
      algorithm: AlgorithmIdentifier | KeyAlgorithm,
      extractable: boolean,
      keyUsages: KeyUsage[]
    ): Promise<CryptoKey> => {
      return {
        type: format === 'raw' ? 'secret' : 'public',
        algorithm: algorithm as Algorithm,
        extractable,
        usages: new Set(keyUsages),
      } as CryptoKey;
    },
    exportKey: async (
      format: KeyFormat,
      key: CryptoKey
    ): Promise<ArrayBuffer | JsonWebKey> => {
      const data = new Uint8Array(32);
      mockCrypto.getRandomValues(data);
      return format === 'raw' ? data.buffer : { kty: 'oct', k: '' };
    },
    deriveKey: async (
      algorithm: AlgorithmIdentifier | KeyDerivationAlgorithm,
      baseKey: CryptoKey,
      derivedKeyType: AlgorithmIdentifier | KeyAlgorithm,
      extractable: boolean,
      keyUsages: KeyUsage[]
    ): Promise<CryptoKey> => {
      return {
        type: 'secret',
        algorithm: derivedKeyType as Algorithm,
        extractable,
        usages: new Set(keyUsages),
      } as CryptoKey;
    },
  },
};

// Mock global crypto object
if (typeof globalThis.crypto === 'undefined') {
  (globalThis as Record<string, unknown>).crypto = mockCrypto;
} else {
  Object.assign(globalThis.crypto, mockCrypto);
}

// Mock IndexedDB for storage tests
const mockIndexedDB = {
  open: (name: string, version: number): IDBOpenDBRequest => {
    return {
      onsuccess: null,
      onerror: null,
      onupgradeneeded: null,
      result: {
        objectStoreNames: {
          contains: () => false,
        },
        createObjectStore: () => ({
          put: () => ({ onsuccess: null, onerror: null }),
          get: () => ({ onsuccess: null, onerror: null }),
          delete: () => ({ onsuccess: null, onerror: null }),
          clear: () => ({ onsuccess: null, onerror: null }),
          getAllKeys: () => ({ onsuccess: null, onerror: null }),
        }),
      },
    } as unknown as IDBOpenDBRequest;
  },
};

// Mock global indexedDB
if (typeof globalThis.indexedDB === 'undefined') {
  (globalThis as Record<string, unknown>).indexedDB = mockIndexedDB;
}

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: (key: string): string | null => store[key] || null,
    setItem: (key: string, value: string): void => { store[key] = value; },
    removeItem: (key: string): void => { delete store[key]; },
    clear: (): void => { store = {}; },
    get length(): number { return Object.keys(store).length; },
    key: (i: number): string | null => Object.keys(store)[i] || null,
  };
})();

if (typeof globalThis.localStorage === 'undefined') {
  Object.defineProperty(globalThis, 'localStorage', { value: localStorageMock });
}

// Suppress console logs during tests
const originalConsole = { ...console };

beforeAll(() => {
  console.log = jest.fn();
  console.info = jest.fn();
  console.warn = jest.fn();
  console.error = jest.fn();
});

afterAll(() => {
  console.log = originalConsole.log;
  console.info = originalConsole.info;
  console.warn = originalConsole.warn;
  console.error = originalConsole.error;
});

// Global test timeout
jest.setTimeout(10000);

// Mock environment for browser APIs
Object.defineProperty(globalThis, 'window', {
  value: {
    crypto: mockCrypto,
    indexedDB: mockIndexedDB,
    localStorage: localStorageMock,
  },
  writable: true,
});
