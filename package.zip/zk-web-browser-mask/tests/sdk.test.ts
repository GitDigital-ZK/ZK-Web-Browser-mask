/**
 * Test Suite for ZK Web Browser Mask SDK
 * 
 * Comprehensive tests for the core functionality.
 */

import {
  ZKWebBrowserMask,
  ZKVerifier,
  MaskAttributes,
  Constraint,
  StorageManager,
  CryptoService,
  MerkleTree,
  bytesToHex,
  hexToBytes,
  randomSalt,
  hashAttributes,
  validateAttributeValue
} from '../sdk';

describe('ZKWebBrowserMask', () => {
  describe('Initialization', () => {
    it('should create a new mask instance', () => {
      const attributes: MaskAttributes = {
        age: { type: 'uint8', value: 25 },
        country: { type: 'string', value: 'US' }
      };

      const mask = new ZKWebBrowserMask({ attributes });
      expect(mask).toBeDefined();
    });

    it('should initialize and generate commitment', async () => {
      const attributes: MaskAttributes = {
        age: { type: 'uint8', value: 30 }
      };

      const mask = new ZKWebBrowserMask({ attributes });
      await mask.initialize();

      const commitment = mask.getCommitment();
      expect(commitment).toBeDefined();
      expect(commitment.value.length).toBeGreaterThan(0);
    });

    it('should generate unique nullifiers', async () => {
      const attributes: MaskAttributes = {
        age: { type: 'uint8', value: 25 }
      };

      const mask1 = new ZKWebBrowserMask({ attributes });
      const mask2 = new ZKWebBrowserMask({ attributes });

      await mask1.initialize();
      await mask2.initialize();

      const nullifier1 = mask1.getNullifier();
      const nullifier2 = mask2.getNullifier();

      // Nullifiers should be different due to random salt
      expect(bytesToHex(nullifier1)).not.toBe(bytesToHex(nullifier2));
    });
  });

  describe('Proof Generation', () => {
    let mask: ZKWebBrowserMask;

    beforeEach(async () => {
      const attributes: MaskAttributes = {
        age: { type: 'uint8', value: 25 },
        country: { type: 'string', value: 'US' },
        verified: { type: 'boolean', value: true }
      };

      mask = new ZKWebBrowserMask({ attributes });
      await mask.initialize();
    });

    it('should generate a proof for valid constraint', async () => {
      const constraints: Constraint[] = [
        { attribute: 'age', operator: '>=', value: 18 }
      ];

      const proof = await mask.generateProof({
        constraints,
        issuer: 'test-issuer'
      });

      expect(proof).toBeDefined();
      expect(proof.proofData).toBeDefined();
      expect(proof.proofData.length).toBeGreaterThan(0);
    });

    it('should reject proofs for invalid constraints', async () => {
      const constraints: Constraint[] = [
        { attribute: 'age', operator: '>=', value: 100 } // Age is 25
      ];

      // The proof will be generated but verification should fail
      const proof = await mask.generateProof({
        constraints,
        issuer: 'test-issuer'
      });

      expect(proof).toBeDefined();
      expect(proof.constraints).toEqual(constraints);
    });

    it('should handle multiple constraints', async () => {
      const constraints: Constraint[] = [
        { attribute: 'age', operator: '>=', value: 18 },
        { attribute: 'age', operator: '<=', value: 100 },
        { attribute: 'verified', operator: '==', value: true }
      ];

      const proof = await mask.generateProof({ constraints });

      expect(proof.constraints.length).toBe(3);
      expect(proof.proofData.length).toBeGreaterThan(0);
    });

    it('should reject non-existent attributes', async () => {
      const constraints: Constraint[] = [
        { attribute: 'nonExistent', operator: '==', value: true }
      ];

      await expect(
        mask.generateProof({ constraints })
      ).rejects.toThrow();
    });

    it('should reject invalid operators', async () => {
      const constraints: Constraint[] = [
        { attribute: 'age', operator: 'invalid', value: 18 } as Constraint
      ];

      await expect(
        mask.generateProof({ constraints })
      ).rejects.toThrow();
    });
  });

  describe('Mask Lifecycle', () => {
    it('should export and import mask', async () => {
      const attributes: MaskAttributes = {
        age: { type: 'uint8', value: 25 }
      };

      const original = new ZKWebBrowserMask({ attributes });
      await original.initialize();

      const exported = await original.export();
      expect(exported.version).toBe('1.0.0');
      expect(exported.attributes.age.value).toBe(25);

      const imported = await ZKWebBrowserMask.import(exported);
      expect(imported.getAttributes().age.value).toBe(25);
    });

    it('should revoke mask', async () => {
      const attributes: MaskAttributes = {
        age: { type: 'uint8', value: 25 }
      };

      const mask = new ZKWebBrowserMask({ attributes });
      await mask.initialize();

      expect(mask.isRevoked()).toBe(false);

      await mask.revoke();
      expect(mask.isRevoked()).toBe(true);
    });

    it('should prevent proof generation after revocation', async () => {
      const attributes: MaskAttributes = {
        age: { type: 'uint8', value: 25 }
      };

      const mask = new ZKWebBrowserMask({ attributes });
      await mask.initialize();
      await mask.revoke();

      await expect(
        mask.generateProof({ constraints: [{ attribute: 'age', operator: '>=', value: 18 }] })
      ).rejects.toThrow(/revoked/i);
    });
  });
});

describe('ZKVerifier', () => {
  let verifier: ZKVerifier;
  let mask: ZKWebBrowserMask;

  beforeEach(async () => {
    verifier = new ZKVerifier({
      options: {
        checkExpiration: true,
        checkNullifier: true
      }
    });

    const attributes: MaskAttributes = {
      age: { type: 'uint8', value: 25 }
    };

    mask = new ZKWebBrowserMask({ attributes });
    await mask.initialize();
  });

  it('should verify a valid proof', async () => {
    const proof = await mask.generateProof({
      constraints: [{ attribute: 'age', operator: '>=', value: 18 }],
      issuer: 'test-issuer'
    });

    const result = await verifier.verify(proof);

    expect(result.isValid).toBe(true);
    expect(result.nullifier).toBeDefined();
  });

  it('should reject expired proofs', async () => {
    const proof = await mask.generateProof({
      constraints: [{ attribute: 'age', operator: '>=', value: 18 }],
      expiration: Date.now() - 1000 // Already expired
    });

    const result = await verifier.verify(proof);
    expect(result.isValid).toBe(false);
    expect(result.error).toContain('expired');
  });

  it('should reject revoked nullifiers', async () => {
    const proof = await mask.generateProof({
      constraints: [{ attribute: 'age', operator: '>=', value: 18 }]
    });

    // Revoke the nullifier
    verifier.revokeNullifier(bytesToHex(proof.nullifier));

    const result = await verifier.verify(proof);
    expect(result.isValid).toBe(false);
    expect(result.error).toContain('revoked');
  });

  it('should manage trusted issuers', () => {
    verifier.addTrustedIssuer('test-issuer', {
      id: 'test-issuer',
      keyData: new Uint8Array(32),
      curve: 'bn128',
      provingScheme: 'groth16'
    });

    expect(verifier.isTrustedIssuer('test-issuer')).toBe(true);
    expect(verifier.isTrustedIssuer('unknown-issuer')).toBe(false);

    verifier.removeTrustedIssuer('test-issuer');
    expect(verifier.isTrustedIssuer('test-issuer')).toBe(false);
  });

  it('should verify batch of proofs', async () => {
    const proof1 = await mask.generateProof({
      constraints: [{ attribute: 'age', operator: '>=', value: 18 }]
    });

    const mask2 = new ZKWebBrowserMask({
      attributes: { age: { type: 'uint8', value: 30 } }
    });
    await mask2.initialize();

    const proof2 = await mask2.generateProof({
      constraints: [{ attribute: 'age', operator: '>=', value: 18 }]
    });

    const results = await verifier.batchVerify([proof1, proof2]);

    expect(results.length).toBe(2);
    expect(results[0].isValid).toBe(true);
    expect(results[1].isValid).toBe(true);
  });
});

describe('CryptoService', () => {
  const crypto = new CryptoService();

  it('should hash data', async () => {
    const data = new TextEncoder().encode('test data');
    const hash = await crypto.hash(data);

    expect(hash).toBeDefined();
    expect(hash.length).toBe(32); // SHA-256 output
  });

  it('should generate random bytes', async () => {
    const bytes = await crypto.generateRandomBytes(32);

    expect(bytes).toBeDefined();
    expect(bytes.length).toBe(32);
  });

  it('should encrypt and decrypt data', async () => {
    const key = await crypto.generateKey();
    const data = new TextEncoder().encode('sensitive data');

    const encrypted = await crypto.encrypt(data, key);
    const decrypted = await crypto.decrypt(encrypted, key);

    expect(new TextDecoder().decode(decrypted)).toBe('sensitive data');
  });

  it('should create commitments', async () => {
    const value = new TextEncoder().encode('value');
    const randomness = await crypto.generateRandomBytes(32);

    const commitment = await crypto.createCommitment(value, randomness);

    expect(commitment).toBeDefined();
    expect(commitment.length).toBe(32);
  });
});

describe('StorageManager', () => {
  it('should save and load data', async () => {
    const storage = new StorageManager({ backend: 'memory' });
    const data = new Uint8Array([1, 2, 3, 4, 5]);

    await storage.save('test-key', data);
    const loaded = await storage.load('test-key');

    expect(loaded).toEqual(data);
  });

  it('should check existence', async () => {
    const storage = new StorageManager({ backend: 'memory' });
    const data = new Uint8Array([1, 2, 3]);

    expect(await storage.exists('test-key')).toBe(false);

    await storage.save('test-key', data);
    expect(await storage.exists('test-key')).toBe(true);
  });

  it('should delete data', async () => {
    const storage = new StorageManager({ backend: 'memory' });
    const data = new Uint8Array([1, 2, 3]);

    await storage.save('test-key', data);
    await storage.delete('test-key');

    expect(await storage.exists('test-key')).toBe(false);
  });

  it('should list all keys', async () => {
    const storage = new StorageManager({ backend: 'memory' });

    await storage.save('key1', new Uint8Array([1]));
    await storage.save('key2', new Uint8Array([2]));
    await storage.save('key3', new Uint8Array([3]));

    const keys = await storage.list();
    expect(keys).toContain('key1');
    expect(keys).toContain('key2');
    expect(keys).toContain('key3');
  });

  it('should clear all data', async () => {
    const storage = new StorageManager({ backend: 'memory' });

    await storage.save('key1', new Uint8Array([1]));
    await storage.save('key2', new Uint8Array([2]));
    await storage.clear();

    const keys = await storage.list();
    expect(keys.length).toBe(0);
  });
});

describe('MerkleTree', () => {
  it('should build a tree', async () => {
    const leaves = [
      new Uint8Array([1]),
      new Uint8Array([2]),
      new Uint8Array([3]),
      new Uint8Array([4])
    ];

    const tree = new MerkleTree(leaves);
    const root = tree.getRoot();

    expect(root).toBeDefined();
    expect(root.length).toBe(32);
  });

  it('should generate and verify proofs', async () => {
    const leaves = [
      new Uint8Array([1]),
      new Uint8Array([2]),
      new Uint8Array([3]),
      new Uint8Array([4])
    ];

    const tree = new MerkleTree(leaves);
    const proof = await tree.getProof(0);

    expect(proof.leaf).toEqual(leaves[0]);
    expect(proof.proof.length).toBeGreaterThan(0);

    const isValid = await MerkleTree.verify(proof);
    expect(isValid).toBe(true);
  });
});

describe('Utility Functions', () => {
  describe('hashAttributes', () => {
    it('should hash attributes consistently', async () => {
      const attributes: MaskAttributes = {
        age: { type: 'uint8', value: 25 },
        name: { type: 'string', value: 'John' }
      };

      const salt = await randomSalt();
      const hash1 = await hashAttributes(attributes, salt);
      const hash2 = await hashAttributes(attributes, salt);

      expect(bytesToHex(hash1)).toBe(bytesToHex(hash2));
    });

    it('should produce different hashes with different salts', async () => {
      const attributes: MaskAttributes = {
        age: { type: 'uint8', value: 25 }
      };

      const salt1 = await randomSalt();
      const salt2 = await randomSalt();

      const hash1 = await hashAttributes(attributes, salt1);
      const hash2 = await hashAttributes(attributes, salt2);

      expect(bytesToHex(hash1)).not.toBe(bytesToHex(hash2));
    });
  });

  describe('bytesToHex and hexToBytes', () => {
    it('should convert bytes to hex and back', () => {
      const original = new Uint8Array([1, 2, 255, 128]);
      const hex = bytesToHex(original);
      const restored = hexToBytes(hex);

      expect(restored).toEqual(original);
    });
  });

  describe('validateAttributeValue', () => {
    it('should validate uint8 values', () => {
      expect(validateAttributeValue(100, 'uint8')).toBe(true);
      expect(validateAttributeValue(255, 'uint8')).toBe(true);
      expect(validateAttributeValue(-1, 'uint8')).toBe(false);
      expect(validateAttributeValue(256, 'uint8')).toBe(false);
      expect(validateAttributeValue(1.5, 'uint8')).toBe(false);
    });

    it('should validate boolean values', () => {
      expect(validateAttributeValue(true, 'boolean')).toBe(true);
      expect(validateAttributeValue(false, 'boolean')).toBe(true);
      expect(validateAttributeValue('true', 'boolean')).toBe(false);
    });

    it('should validate string values', () => {
      expect(validateAttributeValue('hello', 'string')).toBe(true);
      expect(validateAttributeValue('', 'string')).toBe(true);
      expect(validateAttributeValue(123, 'string')).toBe(false);
    });

    it('should validate bytes values', () => {
      expect(validateAttributeValue(new Uint8Array([1, 2, 3]), 'bytes')).toBe(true);
      expect(validateAttributeValue([1, 2, 3], 'bytes')).toBe(false);
    });
  });
});
