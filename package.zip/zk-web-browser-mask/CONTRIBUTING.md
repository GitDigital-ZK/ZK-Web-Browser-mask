# Contributing to ZK Web Browser Mask

Thank you for your interest in contributing to ZK Web Browser Mask! This project aims to provide privacy-preserving identity verification using zero-knowledge proofs. We welcome contributions from developers, researchers, and privacy enthusiasts.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Making Changes](#making-changes)
- [Submitting Changes](#submitting-changes)
- [Bug Reports](#bug-reports)
- [Feature Requests](#feature-requests)
- [Security](#security)
- [Questions](#questions)

## Code of Conduct

By participating in this project, you agree to maintain a respectful and inclusive environment for everyone. We are committed to making participation in this project a harassment-free experience for all, regardless of age, body size, disability, ethnicity, gender identity and expression, level of experience, nationality, personal appearance, race, religion, or sexual identity and orientation.

## Getting Started

1. **Fork the repository** - Create your own copy of the project on GitHub
2. **Clone your fork** - Download a local copy to work on
3. **Choose an issue** - Look through our [issue tracker](https://github.com/your-org/zk-web-browser-mask/issues) for tasks
4. **Ask questions** - If you're unsure about anything, open a discussion

## Development Setup

### Prerequisites

- Node.js 18.0 or higher
- npm 9.0 or higher
- Git 2.30 or higher

### Installation

```bash
# Clone your fork
git clone https://github.com/YOUR_USERNAME/zk-web-browser-mask.git
cd zk-web-browser-mask

# Add upstream remote
git remote add upstream https://github.com/your-org/zk-web-browser-mask.git

# Install dependencies
npm install

# Build the SDK
npm run build:sdk

# Run tests
npm test

# Run tests with coverage
npm run test:coverage
```

### Project Structure

```
zk-web-browser-mask/
├── src/
│   └── sdk/                 # TypeScript SDK source
│       ├── index.ts         # Main entry point
│       ├── mask.ts          # ZKWebBrowserMask class
│       ├── verifier.ts      # ZKVerifier class
│       ├── prover.ts        # ZK prover implementation
│       ├── crypto.ts        # Cryptographic utilities
│       ├── storage.ts       # Storage management
│       ├── utils.ts         # Helper functions
│       └── types.ts         # Type definitions
├── extension/               # Browser extension
│   ├── manifest.json        # Extension manifest
│   ├── background/          # Background service worker
│   ├── popup/               # Extension popup UI
│   └── content/             # Content scripts
├── examples/                # Usage examples
├── tests/                   # Test files
└── docs/                    # Documentation
```

## Making Changes

### Branch Naming

Create a new branch for your changes:

```bash
# For bug fixes
git checkout -b fix/description

# For new features
git checkout -b feature/description

# For documentation
git checkout -b docs/description

# For refactoring
git checkout -b refactor/description
```

### Code Style

We use ESLint and Prettier for code formatting:

```bash
# Format code
npm run format

# Check formatting
npm run format:check

# Run linter
npm run lint
```

**Key style guidelines:**

- Use TypeScript for all new code
- Write descriptive variable and function names
- Add JSDoc comments for public APIs
- Include type annotations for function parameters and return values
- Write unit tests for new functionality

### Testing

All new features should include tests:

```bash
# Run all tests
npm test

# Run specific test file
npm test -- tests/sdk.test.ts

# Run tests in watch mode
npm test -- --watch

# Generate coverage report
npm run test:coverage
```

**Test coverage requirements:**

- New code should maintain at least 80% coverage
- Critical paths should have 90%+ coverage
- All tests must pass before merging

### Commit Messages

Follow the Conventional Commits specification:

```
type(scope): description

[optional body]

[optional footer]
```

**Types:**

- `feat` - New feature
- `fix` - Bug fix
- `docs` - Documentation changes
- `style` - Code style changes (formatting, etc.)
- `refactor` - Code refactoring
- `test` - Adding or updating tests
- `chore` - Maintenance tasks

**Examples:**

```
feat(sdk): add age verification example
fix(verifier): handle expired proofs correctly
docs(readme): update installation instructions
test(mask): add tests for mask export/import
```

## Submitting Changes

### Pull Request Process

1. **Update documentation** - Update README and docs if needed
2. **Add tests** - Ensure all new code has tests
3. **Check formatting** - Run `npm run format` and `npm run lint`
4. **Run tests** - Ensure all tests pass
5. **Push changes** - Push to your fork
6. **Open PR** - Create a pull request against `main`
7. **Wait for review** - Address any feedback

### Pull Request Template

```markdown
## Description
Brief description of changes

## Motivation and Context
Why is this change needed? What problem does it solve?

## Type of Change
- [ ] Bug fix (non-breaking change)
- [ ] New feature (non-breaking change)
- [ ] Breaking change (fix or feature that causes existing functionality to change)
- [ ] Documentation update

## How Has This Been Tested?
Describe the tests you ran to verify your changes

## Checklist
- [ ] My code follows the style guidelines
- [ ] I have performed a self-review
- [ ] I have commented my code where necessary
- [ ] I have updated documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective
- [ ] New and existing tests pass locally
```

## Bug Reports

We use GitHub issues for tracking bugs. When filing a bug report, include:

- **Clear title** - Descriptive title explaining the issue
- **Steps to reproduce** - Detailed steps to reproduce the bug
- **Expected behavior** - What you expected to happen
- **Actual behavior** - What actually happened
- **Environment** - Browser, Node version, OS, etc.
- **Logs** - Any relevant error messages or logs
- **Code sample** - Minimal code that reproduces the issue

## Feature Requests

We welcome feature requests! When requesting a new feature:

- **Describe the feature** - Clear explanation of the feature
- **Use case** - Why is this feature needed?
- **Alternatives considered** - Any alternative solutions you've considered?
- **Additional context** - Any screenshots, mockups, or examples?

## Security

If you discover a security vulnerability, please report it responsibly:

1. **DO NOT** create a public GitHub issue
2. **Email** security@zkwebbrowsermask.org with details
3. **Wait** for our response (usually within 48 hours)
4. **Coordinate** any public disclosure with us

### Security Best Practices

When contributing code:

- Never commit secrets or credentials
- Use secure random number generation
- Follow cryptographic best practices
- Validate all inputs
- Handle errors securely (no sensitive data in error messages)

## Questions

For general questions and discussions:

- **GitHub Discussions** - For questions about using the project
- **Issues** - For bug reports and feature requests
- **Discord** - For real-time community discussions

## Recognition

Contributors will be recognized in:

- Our README.md contributors section
- Release notes
- Our Discord server's contributor roles

## License

By contributing to ZK Web Browser Mask, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing to ZK Web Browser Mask! Together, we're building a more private and secure web.
