/**
 * ZK Web Browser Mask - Popup Script
 * 
 * Handles popup UI interactions and communication with background service.
 */

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  await loadMasks();
  await loadConsentRequests();
  await loadSettings();
  setupEventListeners();
});

/**
 * Load and display masks
 */
async function loadMasks() {
  try {
    const masks = await sendMessage({ type: 'GET_MASKS' });
    updateMaskList(masks);
  } catch (error) {
    console.error('Failed to load masks:', error);
  }
}

/**
 * Update mask list UI
 */
function updateMaskList(masks) {
  const maskList = document.getElementById('maskList');
  const maskCount = document.getElementById('maskCount');
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');

  maskCount.textContent = masks.length;

  if (masks.length === 0) {
    statusDot.classList.add('inactive');
    statusText.textContent = 'No Active Masks';
    maskList.innerHTML = `
      <div class="empty-state">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
        <p>No masks created yet</p>
        <button class="btn btn-primary btn-block" onclick="showCreateModal()">Create Your First Mask</button>
      </div>
    `;
    return;
  }

  statusDot.classList.remove('inactive');
  statusText.textContent = 'Active';

  maskList.innerHTML = masks.map(mask => `
    <div class="mask-item">
      <div class="mask-header">
        <span class="mask-id">${mask.id.slice(0, 16)}...</span>
        <span class="mask-badge">Active</span>
      </div>
      <div class="mask-commitment">${mask.commitment.slice(0, 32)}...</div>
      <div class="mask-actions">
        <button class="btn btn-primary" onclick="generateProof('${mask.id}')">Generate Proof</button>
        <button class="btn btn-danger" onclick="deleteMask('${mask.id}')">Delete</button>
      </div>
    </div>
  `).join('') + `
    <button class="btn btn-outline btn-block" onclick="showCreateModal()">Create New Mask</button>
  `;
}

/**
 * Load consent requests
 */
async function loadConsentRequests() {
  try {
    const requests = await sendMessage({ type: 'GET_CONSENT_REQUESTS' });
    updateConsentList(requests);
  } catch (error) {
    console.error('Failed to load consent requests:', error);
  }
}

/**
 * Update consent requests UI
 */
function updateConsentList(requests) {
  const consentList = document.getElementById('consentList');

  if (requests.length === 0) {
    consentList.innerHTML = `
      <div class="empty-state">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p>No pending requests</p>
      </div>
    `;
    return;
  }

  consentList.innerHTML = requests.map(request => `
    <div class="consent-item">
      <div class="consent-header">
        <span class="consent-domain">${request.domain}</span>
        <span class="consent-time">${formatTime(request.timestamp)}</span>
      </div>
      <div class="consent-reason">${request.reason}</div>
      <div class="consent-actions">
        <button class="btn btn-primary" onclick="respondToConsent('${request.id}', true)">Approve</button>
        <button class="btn btn-danger" onclick="respondToConsent('${request.id}', false)">Deny</button>
      </div>
    </div>
  `).join('');
}

/**
 * Load settings
 */
async function loadSettings() {
  try {
    const settings = await sendMessage({ type: 'GET_SETTINGS' });
    
    document.getElementById('autoApprove').checked = settings.autoApprove;
    document.getElementById('showNotifications').checked = settings.showNotifications;
    document.getElementById('encryptionEnabled').checked = settings.encryptionEnabled;
  } catch (error) {
    console.error('Failed to load settings:', error);
  }
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
  // Tab switching
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      
      tab.classList.add('active');
      document.getElementById(`${tab.dataset.tab}-tab`).classList.add('active');
    });
  });

  // Settings changes
  document.getElementById('autoApprove').addEventListener('change', (e) => {
    sendMessage({ type: 'UPDATE_SETTINGS', payload: { autoApprove: e.target.checked } });
  });

  document.getElementById('showNotifications').addEventListener('change', (e) => {
    sendMessage({ type: 'UPDATE_SETTINGS', payload: { showNotifications: e.target.checked } });
  });

  document.getElementById('encryptionEnabled').addEventListener('change', (e) => {
    sendMessage({ type: 'UPDATE_SETTINGS', payload: { encryptionEnabled: e.target.checked } });
  });

  // Create mask form
  document.getElementById('createMaskForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    await createMask();
  });
}

/**
 * Show create mask modal
 */
function showCreateModal() {
  document.getElementById('createModal').classList.add('active');
}

/**
 * Hide create mask modal
 */
function hideCreateModal() {
  document.getElementById('createModal').classList.remove('active');
  document.getElementById('createMaskForm').reset();
}

/**
 * Create a new mask
 */
async function createMask() {
  const age = parseInt(document.getElementById('maskAge').value);
  const country = document.getElementById('maskCountry').value;
  const verified = document.getElementById('maskVerified').value === 'true';

  try {
    await sendMessage({
      type: 'CREATE_MASK',
      payload: {
        attributes: {
          age: { type: 'uint8', value: age },
          country: { type: 'string', value: country },
          verified: { type: 'boolean', value: verified }
        },
        domains: ['*'] // Allow all domains
      }
    });

    hideCreateModal();
    await loadMasks();
  } catch (error) {
    console.error('Failed to create mask:', error);
    alert('Failed to create mask: ' + error.message);
  }
}

/**
 * Delete a mask
 */
async function deleteMask(maskId) {
  if (!confirm('Are you sure you want to delete this mask?')) {
    return;
  }

  try {
    await sendMessage({ type: 'DELETE_MASK', payload: { maskId } });
    await loadMasks();
  } catch (error) {
    console.error('Failed to delete mask:', error);
  }
}

/**
 * Generate a proof for a mask
 */
async function generateProof(maskId) {
  try {
    // Get current tab URL
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const domain = new URL(tab.url).hostname;

    const proof = await sendMessage({
      type: 'GENERATE_PROOF',
      payload: {
        maskId,
        constraints: [
          { attribute: 'age', operator: '>=', value: 18 }
        ],
        domain
      }
    });

    // Send proof to the page
    chrome.tabs.sendMessage(tab.id, {
      type: 'PROOF_GENERATED',
      payload: proof
    });

    alert('Proof generated and sent to ' + domain);
  } catch (error) {
    console.error('Failed to generate proof:', error);
    alert('Failed to generate proof: ' + error.message);
  }
}

/**
 * Respond to a consent request
 */
async function respondToConsent(requestId, granted) {
  try {
    await sendMessage({
      type: 'RESPOND_TO_CONSENT',
      payload: { requestId, granted }
    });
    await loadConsentRequests();
  } catch (error) {
    console.error('Failed to respond to consent:', error);
  }
}

/**
 * Export masks
 */
async function exportMasks() {
  try {
    const data = await sendMessage({ type: 'EXPORT_MASKS' });
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `zk-masks-backup-${Date.now()}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Failed to export masks:', error);
    alert('Failed to export masks: ' + error.message);
  }
}

/**
 * Import masks
 */
async function importMasks(event) {
  const file = event.target.files[0];
  if (!file) return;

  try {
    const text = await file.text();
    await sendMessage({ type: 'IMPORT_MASKS', payload: { data: text } });
    await loadMasks();
    alert('Masks imported successfully!');
  } catch (error) {
    console.error('Failed to import masks:', error);
    alert('Failed to import masks: ' + error.message);
  }
}

/**
 * Open dashboard
 */
function openDashboard() {
  chrome.tabs.create({ url: 'dashboard/dashboard.html' });
}

/**
 * Send message to background service
 */
function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (response.error) {
        reject(new Error(response.error));
      } else {
        resolve(response);
      }
    });
  });
}

/**
 * Format timestamp
 */
function formatTime(timestamp) {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
