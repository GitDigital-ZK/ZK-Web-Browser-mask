/**
 * ZK Web Browser Mask - Content Script
 * 
 * Injected into web pages to provide ZK proof API.
 */

(function() {
  'use strict';

  // Prevent multiple injections
  if (window.__ZKBrowserMaskLoaded) {
    return;
  }
  window.__ZKBrowserMaskLoaded = true;

  /**
   * ZK Browser API exposed to web pages
   */
  const zkBrowserAPI = {
    /**
     * Check if user has any masks
     */
    hasMask: async function(domain) {
      try {
        const masks = await sendToBackground({ type: 'GET_MASKS' });
        return masks.some(m => m.domains.includes(domain) || m.domains.includes('*'));
      } catch (error) {
        console.error('ZK Mask: Failed to check mask:', error);
        return false;
      }
    },

    /**
     * Request a proof from the user
     */
    requestProof: async function(request) {
      if (!request || !request.constraints) {
        throw new Error('Invalid proof request');
      }

      // Get current domain
      const domain = window.location.hostname;

      // Find user's mask for this domain
      const masks = await sendToBackground({ type: 'GET_MASKS' });
      const mask = masks.find(m => 
        m.domains.includes(domain) || m.domains.includes('*')
      );

      if (!mask) {
        throw new Error('No mask found for this domain. Please create one in the extension popup.');
      }

      // Request consent if needed
      await sendToBackground({
        type: 'REQUEST_CONSENT',
        payload: {
          id: `consent_${Date.now()}`,
          domain,
          constraints: request.constraints,
          reason: request.reason || 'Identity verification request',
          timestamp: Date.now(),
          proofRequest: request
        }
      });

      // Return a promise that resolves when consent is granted
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          listener.remove();
          reject(new Error('Proof request timed out'));
        }, request.timeout || 60000);

        const listener = (message) => {
          if (message.type === 'CONSENT_RESPONSE' && 
              message.payload.requestId.includes('consent_') &&
              message.payload.domain === domain) {
            clearTimeout(timeout);
            listener.remove();

            if (message.payload.granted) {
              // Generate the proof
              sendToBackground({
                type: 'GENERATE_PROOF',
                payload: {
                  maskId: mask.id,
                  constraints: request.constraints,
                  domain
                }
              }).then(resolve).catch(reject);
            } else {
              reject(new Error('User denied consent'));
            }
          }
        };

        chrome.runtime.onMessage.addListener(listener);
      });
    },

    /**
     * Get user's masks for this domain
     */
    getMasks: async function(domain) {
      const domainToCheck = domain || window.location.hostname;
      const masks = await sendToBackground({ type: 'GET_MASKS' });
      return masks.filter(m => 
        m.domains.includes(domainToCheck) || m.domains.includes('*')
      );
    },

    /**
     * Register a new mask
     */
    registerMask: async function(attributes) {
      return await sendToBackground({
        type: 'CREATE_MASK',
        payload: {
          attributes,
          domains: [window.location.hostname]
        }
      });
    },

    /**
     * Get pending consent requests
     */
    getConsentRequests: async function() {
      return await sendToBackground({ type: 'GET_CONSENT_REQUESTS' });
    },

    /**
     * Respond to a consent request
     */
    respondToConsent: async function(requestId, granted) {
      return await sendToBackground({
        type: 'RESPOND_TO_CONSENT',
        payload: { requestId, granted }
      });
    }
  };

  // Expose API to window
  window.zkBrowserAPI = zkBrowserAPI;

  // Also expose as a provider script for easy integration
  const providerScript = document.createElement('script');
  providerScript.src = chrome.runtime.getURL('provider/provider.js');
  (document.head || document.documentElement).appendChild(providerScript);

  /**
   * Send message to background service
   */
  function sendToBackground(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (response.error) {
          reject(new Error(response.error));
        } else {
          resolve(response);
        }
      });
    });
  }

  // Listen for proof generated events
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'PROOF_GENERATED') {
      // Dispatch custom event for web pages to listen
      const event = new CustomEvent('zkproofgenerated', {
        detail: message.payload
      });
      document.dispatchEvent(event);
    }
  });

  console.log('ZK Web Browser Mask content script loaded');
})();
