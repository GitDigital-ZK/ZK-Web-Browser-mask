/**
 * ZK Web Browser Mask - Provider Script
 * 
 * Easy integration script for web developers to add ZK verification
 * to their applications without installing the extension.
 */

(function() {
  'use strict';

  // Configuration
  const DEFAULT_CONFIG = {
    debug: false,
    autoInit: true,
    providerEndpoint: 'https://api.zkwebbrowsermask.org',
  };

  let config = { ...DEFAULT_CONFIG };
  let isInitialized = false;
  let provider = null;

  /**
   * Initialize the ZK provider
   */
  async function initialize(options = {}) {
    config = { ...config, ...options };

    if (config.debug) {
      console.log('ZK Provider: Initializing...');
    }

    // Check if extension is available
    if (window.zkBrowserAPI) {
      provider = window.zkBrowserAPI;
      isInitialized = true;
      
      if (config.debug) {
        console.log('ZK Provider: Using browser extension');
      }
      return;
    }

    // Fallback to server-side verification
    provider = createServerProvider();
    isInitialized = true;

    if (config.debug) {
      console.log('ZK Provider: Using server-side verification');
    }
  }

  /**
   * Create server-side provider fallback
   */
  function createServerProvider() {
    return {
      hasMask: async function(domain) {
        // Check with server if user has registered mask
        try {
          const response = await fetch(`${config.providerEndpoint}/api/mask/check`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ domain }),
            credentials: 'include',
          });
          return response.ok;
        } catch (error) {
          if (config.debug) {
            console.error('ZK Provider: Failed to check mask:', error);
          }
          return false;
        }
      },

      requestProof: async function(request) {
        // Redirect to verification page
        const verificationUrl = new URL(`${config.providerEndpoint}/verify`);
        verificationUrl.searchParams.set('constraints', JSON.stringify(request.constraints));
        verificationUrl.searchParams.set('return_url', window.location.href);
        verificationUrl.searchParams.set('app_id', window.location.hostname);

        // Open verification in popup or redirect
        const width = 500;
        const height = 600;
        const left = window.screenX + (window.outerWidth - width) / 2;
        const top = window.screenY + (window.outerHeight - height) / 2;

        const popup = window.open(
          verificationUrl.href,
          'zk_verification',
          `width=${width},height=${height},left=${left},top=${top},popup=yes`
        );

        if (!popup) {
          // Fallback to redirect
          window.location.href = verificationUrl.href;
        }

        // Listen for verification result
        return new Promise((resolve, reject) => {
          const messageHandler = (event) => {
            if (event.data?.type === 'zk_proof_result') {
              window.removeEventListener('message', messageHandler);
              if (event.data.success) {
                resolve(event.data.proof);
              } else {
                reject(new Error(event.data.error || 'Verification failed'));
              }
            }
          };

          window.addEventListener('message', messageHandler);

          // Timeout after 5 minutes
          setTimeout(() => {
            window.removeEventListener('message', messageHandler);
            reject(new Error('Verification timeout'));
          }, 300000);
        });
      },

      getMasks: async function(domain) {
        try {
          const response = await fetch(`${config.providerEndpoint}/api/masks`, {
            method: 'GET',
            credentials: 'include',
          });
          const data = await response.json();
          return data.masks || [];
        } catch (error) {
          if (config.debug) {
            console.error('ZK Provider: Failed to get masks:', error);
          }
          return [];
        }
      },
    };
  }

  /**
   * Request age verification
   */
  async function verifyAge(minAge) {
    if (!isInitialized) {
      await initialize();
    }

    return provider.requestProof({
      constraints: [
        { attribute: 'age', operator: '>=', value: minAge },
      ],
      reason: `Age verification required (minimum ${minAge})`,
    });
  }

  /**
   * Request membership verification
   */
  async function verifyMembership(minTier) {
    if (!isInitialized) {
      await initialize();
    }

    return provider.requestProof({
      constraints: [
        { attribute: 'tier', operator: '>=', value: minTier },
        { attribute: 'subscriptionActive', operator: '==', value: true },
      ],
      reason: 'Membership verification required',
    });
  }

  /**
   * Request custom verification
   */
  async function verify(constraints, options = {}) {
    if (!isInitialized) {
      await initialize();
    }

    return provider.requestProof({
      constraints,
      reason: options.reason || 'Identity verification required',
      ...options,
    });
  }

  /**
   * Check if user has verified identity
   */
  async function hasVerification(domain) {
    if (!isInitialized) {
      await initialize();
    }

    return provider.hasMask(domain || window.location.hostname);
  }

  // Create global API
  window.ZKVerify = {
    init: initialize,
    verifyAge,
    verifyMembership,
    verify,
    hasVerification,
    config: (options) => {
      config = { ...config, ...options };
    },
    VERSION: '1.0.0',
  };

  // Auto-initialize if enabled
  if (DEFAULT_CONFIG.autoInit && document.readyState !== 'loading') {
    initialize();
  } else if (DEFAULT_CONFIG.autoInit) {
    document.addEventListener('DOMContentLoaded', () => initialize());
  }

  console.log('ZK Web Browser Mask Provider loaded');
})();
