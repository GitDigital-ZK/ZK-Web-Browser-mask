/**
 * ZK Web Browser Mask - Browser Extension Background Service
 * 
 * Handles communication between popup, content scripts, and the ZK SDK.
 */

// Extension state
interface ExtensionState {
  masks: Map<string, MaskData>;
  consentRequests: ConsentRequest[];
  auditLog: AuditLogEntry[];
  settings: ExtensionSettings;
}

interface MaskData {
  id: string;
  commitment: string;
  attributes: Record<string, unknown>;
  createdAt: number;
  expiresAt?: number;
  domains: string[];
}

interface ConsentRequest {
  id: string;
  domain: string;
  constraints: unknown[];
  reason: string;
  timestamp: number;
  proofRequest?: unknown;
}

interface AuditLogEntry {
  id: string;
  action: string;
  timestamp: number;
  details: Record<string, unknown>;
}

interface ExtensionSettings {
  autoApprove: boolean;
  showNotifications: boolean;
  encryptionEnabled: boolean;
}

const state: ExtensionState = {
  masks: new Map(),
  consentRequests: [],
  auditLog: [],
  settings: {
    autoApprove: false,
    showNotifications: true,
    encryptionEnabled: true
  }
};

// Message handlers
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then(sendResponse)
    .catch(error => sendResponse({ error: error.message }));
  return true; // Indicates async response
});

async function handleMessage(message: { type: string; payload?: unknown }, sender: chrome.runtime.MessageSender): Promise<unknown> {
  const { type, payload } = message;

  switch (type) {
    case 'CREATE_MASK':
      return await createMask(payload as { attributes: Record<string, unknown>; domains: string[] });
    
    case 'GET_MASKS':
      return getMasks();
    
    case 'DELETE_MASK':
      return await deleteMask(payload as { maskId: string });
    
    case 'GENERATE_PROOF':
      return await generateProof(payload as { maskId: string; constraints: unknown[]; domain: string });
    
    case 'REQUEST_CONSENT':
      return await requestConsent(payload as ConsentRequest);
    
    case 'RESPOND_TO_CONSENT':
      return await respondToConsent(payload as { requestId: string; granted: boolean });
    
    case 'GET_CONSENT_REQUESTS':
      return getConsentRequests();
    
    case 'GET_SETTINGS':
      return getSettings();
    
    case 'UPDATE_SETTINGS':
      return await updateSettings(payload as Partial<ExtensionSettings>);
    
    case 'GET_AUDIT_LOG':
      return getAuditLog();
    
    case 'EXPORT_MASKS':
      return await exportMasks();
    
    case 'IMPORT_MASKS':
      return await importMasks(payload as { data: string });
    
    default:
      throw new Error(`Unknown message type: ${type}`);
  }
}

// Mask operations
async function createMask(data: { attributes: Record<string, unknown>; domains: string[] }): Promise<MaskData> {
  const maskId = `mask_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
  
  const maskData: MaskData = {
    id: maskId,
    commitment: generateMockCommitment(),
    attributes: data.attributes,
    createdAt: Date.now(),
    domains: data.domains
  };

  state.masks.set(maskId, maskData);
  
  addAuditLogEntry('mask_created', {
    maskId,
    domains: data.domains
  });

  // Save to storage
  await saveMasksToStorage();

  return maskData;
}

function getMasks(): MaskData[] {
  return Array.from(state.masks.values());
}

async function deleteMask(data: { maskId: string }): Promise<void> {
  const deleted = state.masks.delete(data.maskId);
  
  if (deleted) {
    addAuditLogEntry('mask_deleted', { maskId: data.maskId });
    await saveMasksToStorage();
  }
}

async function generateProof(data: { maskId: string; constraints: unknown[]; domain: string }): Promise<unknown> {
  const mask = state.masks.get(data.maskId);
  
  if (!mask) {
    throw new Error('Mask not found');
  }

  if (!mask.domains.includes(data.domain) && !mask.domains.includes('*')) {
    throw new Error('Domain not authorized for this mask');
  }

  // In production, this would call the ZK SDK
  const proof = {
    proofData: generateMockProofData(),
    publicSignals: {
      commitment: mask.commitment,
      nullifier: generateMockNullifier()
    },
    proofType: 'multi_attribute',
    createdAt: Date.now(),
    expiresAt: Date.now() + 86400000,
    constraints: data.constraints
  };

  addAuditLogEntry('proof_generated', {
    maskId: data.maskId,
    domain: data.domain,
    constraintsCount: (data.constraints as unknown[]).length
  });

  return proof;
}

// Consent operations
async function requestConsent(request: ConsentRequest): Promise<void> {
  state.consentRequests.push(request);
  
  // Show notification if enabled
  if (state.settings.showNotifications) {
    chrome.notifications?.create({
      type: 'basic',
      iconUrl: 'icons/icon-48.png',
      title: 'ZK Mask - Consent Request',
      message: `${request.domain} is requesting identity verification. Reason: ${request.reason}`
    });
  }
}

async function respondToConsent(data: { requestId: string; granted: boolean }): Promise<void> {
  const index = state.consentRequests.findIndex(r => r.id === data.requestId);
  
  if (index === -1) {
    throw new Error('Consent request not found');
  }

  const request = state.consentRequests[index];
  state.consentRequests.splice(index, 1);

  addAuditLogEntry(data.granted ? 'consent_granted' : 'consent_denied', {
    requestId: data.requestId,
    domain: request.domain
  });

  // Notify content script
  const tabs = await chrome.tabs.query({ url: `*://${request.domain}/*` });
  tabs.forEach(tab => {
    if (tab.id) {
      chrome.tabs.sendMessage(tab.id, {
        type: 'CONSENT_RESPONSE',
        payload: {
          requestId: data.requestId,
          granted: data.granted
        }
      });
    }
  });
}

function getConsentRequests(): ConsentRequest[] {
  return [...state.consentRequests];
}

// Settings operations
function getSettings(): ExtensionSettings {
  return { ...state.settings };
}

async function updateSettings(newSettings: Partial<ExtensionSettings>): Promise<void> {
  state.settings = { ...state.settings, ...newSettings };
  await chrome.storage.local.set({ settings: state.settings });
}

// Audit log operations
function addAuditLogEntry(action: string, details: Record<string, unknown>): void {
  const entry: AuditLogEntry = {
    id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    action,
    timestamp: Date.now(),
    details
  };

  state.auditLog.push(entry);
  
  // Keep only last 1000 entries
  if (state.auditLog.length > 1000) {
    state.auditLog = state.auditLog.slice(-1000);
  }
}

function getAuditLog(): AuditLogEntry[] {
  return [...state.auditLog];
}

// Import/Export operations
async function exportMasks(): Promise<string> {
  const data = {
    version: '1.0.0',
    exportedAt: Date.now(),
    masks: Array.from(state.masks.values()),
    settings: state.settings
  };

  return JSON.stringify(data);
}

async function importMasks(data: { data: string }): Promise<void> {
  const parsed = JSON.parse(data.data);
  
  if (parsed.version !== '1.0.0') {
    throw new Error('Unsupported export version');
  }

  state.masks = new Map(parsed.masks.map((m: MaskData) => [m.id, m]));
  state.settings = { ...state.settings, ...parsed.settings };

  addAuditLogEntry('masks_imported', {
    maskCount: parsed.masks.length
  });

  await saveMasksToStorage();
}

// Storage helpers
async function saveMasksToStorage(): Promise<void> {
  const masksArray = Array.from(state.masks.entries());
  await chrome.storage.local.set({
    masks: masksArray,
    settings: state.settings
  });
}

async function loadMasksFromStorage(): Promise<void> {
  const result = await chrome.storage.local.get(['masks', 'settings']);
  
  if (result.masks) {
    state.masks = new Map(result.masks);
  }
  
  if (result.settings) {
    state.settings = result.settings;
  }
}

// Utility functions
function generateMockCommitment(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}

function generateMockProofData(): Uint8Array {
  const bytes = new Uint8Array(256);
  crypto.getRandomValues(bytes);
  return bytes;
}

function generateMockNullifier(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}

// Initialize
loadMasksFromStorage().catch(console.error);

console.log('ZK Web Browser Mask background service initialized');
