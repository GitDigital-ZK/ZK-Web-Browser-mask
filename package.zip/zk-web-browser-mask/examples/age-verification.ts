/**
 * Example: Age Verification Gate
 * 
 * This example demonstrates how to implement age-restricted content access
 * using zero-knowledge proofs.
 */

import { ZKWebBrowserMask, ZKVerifier, MaskAttributes } from '../sdk';

/**
 * Service provider configuration
 */
interface ServiceProviderConfig {
  minAge: number;
  trustedIssuers: string[];
  proofMaxAge: number;
}

/**
 * User-side age gate
 */
export class AgeGateUser {
  private mask: ZKWebBrowserMask;
  private config: ServiceProviderConfig;

  constructor(attributes: MaskAttributes, config: ServiceProviderConfig) {
    this.config = config;
    this.mask = new ZKWebBrowserMask({
      attributes,
      requireUserConsent: true,
      auditLogging: true
    });
  }

  /**
   * Initialize the age gate
   */
  public async initialize(): Promise<void> {
    await this.mask.initialize();
  }

  /**
   * Generate an age verification proof
   */
  public async verifyAge(): Promise<{
    proof: Uint8Array;
    commitment: Uint8Array;
  }> {
    const proof = await this.mask.generateProof({
      constraints: [
        { attribute: 'age', operator: '>=', value: this.config.minAge }
      ],
      issuer: 'kyc-provider',
      audience: 'age-restricted-content',
      expiration: Date.now() + 3600000 // 1 hour
    });

    return {
      proof: proof.proofData,
      commitment: this.mask.getCommitment().value
    };
  }

  /**
   * Get the commitment for registration
   */
  public getCommitment(): Uint8Array {
    return this.mask.getCommitment().value;
  }

  /**
   * Export the mask for backup
   */
  public async exportMask(): Promise<string> {
    const exported = await this.mask.export();
    return JSON.stringify(exported);
  }
}

/**
 * Service provider-side age verification
 */
export class AgeGateProvider {
  private verifier: ZKVerifier;
  private config: ServiceProviderConfig;
  private verifiedUsers: Map<string, { expiresAt: number; minAge: number }>;

  constructor(config: ServiceProviderConfig) {
    this.config = config;
    this.verifiedUsers = new Map();

    this.verifier = new ZKVerifier({
      options: {
        checkExpiration: true,
        maxProofAge: config.proofMaxAge,
        checkNullifier: true,
        allowRevocation: true
      }
    });

    // Add trusted issuers
    config.trustedIssuers.forEach(issuer => {
      this.verifier.addTrustedIssuer(issuer, {
        id: issuer,
        keyData: new Uint8Array(32),
        curve: 'bn128',
        provingScheme: 'groth16'
      });
    });
  }

  /**
   * Verify an age proof
   */
  public async verifyAgeProof(
    proof: Uint8Array,
    commitment: Uint8Array,
    minAge: number
  ): Promise<{
    valid: boolean;
    error?: string;
    nullifier?: string;
  }> {
    // Reconstruct the proof object
    const zkProof = {
      proofData: proof,
      publicSignals: {
        commitment: Array.from(commitment).map(b => b.toString(16)).join(''),
        nullifier: '',
        timestamp: Date.now()
      },
      proofType: 'age_verification',
      createdAt: Date.now(),
      expiresAt: Date.now() + 3600000,
      issuer: 'kyc-provider',
      nullifier: new Uint8Array(32),
      constraints: [{ attribute: 'age', operator: '>=', value: minAge }]
    };

    const result = await this.verifier.verify(zkProof);

    if (result.isValid) {
      // Store verified user
      this.verifiedUsers.set(result.nullifier, {
        expiresAt: Date.now() + 3600000,
        minAge
      });
    }

    return {
      valid: result.isValid,
      error: result.error,
      nullifier: result.nullifier
    };
  }

  /**
   * Check if a user is verified
   */
  public isVerified(nullifier: string): boolean {
    const verification = this.verifiedUsers.get(nullifier);
    if (!verification) {
      return false;
    }
    return Date.now() < verification.expiresAt;
  }

  /**
   * Revoke a user's verification
   */
  public revokeUser(nullifier: string): void {
    this.verifier.revokeNullifier(nullifier);
    this.verifiedUsers.delete(nullifier);
  }
}

/**
 * Express middleware for age-restricted routes
 */
export function createAgeVerificationMiddleware(
  provider: AgeGateProvider,
  minAge: number
) {
  return async (req: { headers: Record<string, string>; cookies: Record<string, string> }, res: { status: (code: number) => { json: (data: unknown) => void }; json: (data: unknown) => void }, next: () => void) => {
    const nullifier = req.cookies?.age_verified;

    if (!nullifier) {
      return res.status(401).json({
        error: 'Age verification required',
        minAge,
        verificationEndpoint: '/api/verify-age'
      });
    }

    if (!provider.isVerified(nullifier)) {
      return res.status(403).json({
        error: 'Age verification expired',
        minAge,
        verificationEndpoint: '/api/verify-age'
      });
    }

    next();
  };
}

/**
 * Demo usage
 */
export async function demoAgeGate() {
  console.log('=== Age Gate Demo ===\n');

  // User setup
  const userAttributes: MaskAttributes = {
    age: { type: 'uint8', value: 25 },
    kycVerified: { type: 'boolean', value: true },
    country: { type: 'string', value: 'US' }
  };

  const config: ServiceProviderConfig = {
    minAge: 21,
    trustedIssuers: ['government-agency', 'passport-authority'],
    proofMaxAge: 3600000 // 1 hour
  };

  // Create user-side age gate
  const userGate = new AgeGateUser(userAttributes, config);
  await userGate.initialize();

  console.log('User: Mask initialized');
  console.log('User: Commitment created:', userGate.getCommitment().slice(0, 16).toString() + '...');

  // Generate proof
  const { proof, commitment } = await userGate.verifyAge();
  console.log('User: Age proof generated');
  console.log('Proof size:', proof.length, 'bytes\n');

  // Create provider-side verification
  const providerGate = new AgeGateProvider(config);

  // Verify proof
  const verification = await providerGate.verifyAgeProof(proof, commitment, 21);
  
  if (verification.valid) {
    console.log('Provider: Age verification successful');
    console.log('Nullifier:', verification.nullifier?.slice(0, 16) + '...');
    console.log('User is', 25, 'years old (>= 21 required)\n');
  } else {
    console.log('Provider: Verification failed:', verification.error);
  }

  // Test with underage user
  console.log('=== Testing with underage user ===\n');
  
  const underageAttributes: MaskAttributes = {
    age: { type: 'uint8', value: 17 },
    kycVerified: { type: 'boolean', value: true }
  };

  const underageUser = new AgeGateUser(underageAttributes, config);
  await underageUser.initialize();

  try {
    await underageUser.verifyAge();
    console.log('ERROR: Should have failed for underage user');
  } catch (error) {
    console.log('Correctly rejected underage user:', (error as Error).message);
  }
}

// Run demo if executed directly
if (typeof require !== 'undefined' && require.main === module) {
  demoAgeGate().catch(console.error);
}
