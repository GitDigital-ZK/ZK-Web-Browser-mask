/**
 * Example: Membership Verification
 * 
 * This example demonstrates how to verify user membership tiers
 * and subscription status without revealing account details.
 */

import { ZKWebBrowserMask, ZKVerifier, MaskAttributes, Constraint } from '../sdk';

/**
 * Membership tier definitions
 */
enum MembershipTier {
  FREE = 0,
  BASIC = 1,
  PREMIUM = 2,
  ENTERPRISE = 3
}

/**
 * Feature access mapping
 */
const FEATURE_ACCESS: Record<string, MembershipTier[]> = {
  'basic-content': [MembershipTier.FREE, MembershipTier.BASIC, MembershipTier.PREMIUM, MembershipTier.ENTERPRISE],
  'premium-content': [MembershipTier.PREMIUM, MembershipTier.ENTERPRISE],
  'api-access': [MembershipTier.BASIC, MembershipTier.PREMIUM, MembershipTier.ENTERPRISE],
  'enterprise-features': [MembershipTier.ENTERPRISE],
  'priority-support': [MembershipTier.PREMIUM, MembershipTier.ENTERPRISE]
};

/**
 * User-side membership manager
 */
export class MembershipUser {
  private mask: ZKWebBrowserMask;
  private tier: MembershipTier;
  private subscriptionActive: boolean;

  constructor(tier: MembershipTier, subscriptionActive: boolean) {
    this.tier = tier;
    this.subscriptionActive = subscriptionActive;

    const attributes: MaskAttributes = {
      tier: { type: 'uint8', value: tier },
      subscriptionActive: { type: 'boolean', value: subscriptionActive },
      memberSince: { type: 'uint32', value: Math.floor(Date.now() / 1000) - 86400 * 365 }
    };

    this.mask = new ZKWebBrowserMask({
      attributes,
      requireUserConsent: true
    });
  }

  /**
   * Initialize the membership mask
   */
  public async initialize(): Promise<void> {
    await this.mask.initialize();
  }

  /**
   * Generate a proof for accessing a feature
   */
  public async proveFeatureAccess(feature: string): Promise<{
    proof: Uint8Array;
    commitment: Uint8Array;
  }> {
    const requiredTier = this.getRequiredTier(feature);

    const constraints: Constraint[] = [
      { attribute: 'tier', operator: '>=', value: requiredTier },
      { attribute: 'subscriptionActive', operator: '==', value: true }
    ];

    const proof = await this.mask.generateProof({
      constraints,
      audience: 'membership-verification',
      expiration: Date.now() + 86400000 // 24 hours
    });

    return {
      proof: proof.proofData,
      commitment: this.mask.getCommitment().value
    };
  }

  /**
   * Generate a multi-feature proof
   */
  public async proveMultipleFeatures(features: string[]): Promise<{
    proof: Uint8Array;
    commitment: Uint8Array;
  }> {
    // Find the highest required tier
    const requiredTier = Math.max(...features.map(f => this.getRequiredTier(f)));

    const constraints: Constraint[] = [
      { attribute: 'tier', operator: '>=', value: requiredTier },
      { attribute: 'subscriptionActive', operator: '==', value: true }
    ];

    const proof = await this.mask.generateProof({
      constraints,
      audience: 'membership-verification',
      metadata: { features },
      expiration: Date.now() + 86400000
    });

    return {
      proof: proof.proofData,
      commitment: this.mask.getCommitment().value
    };
  }

  /**
   * Get the required tier for a feature
   */
  private getRequiredTier(feature: string): number {
    const tiers = FEATURE_ACCESS[feature];
    if (!tiers || tiers.length === 0) {
      return MembershipTier.ENTERPRISE; // Default to highest
    }
    return Math.min(...tiers);
  }
}

/**
 * Service provider-side membership verification
 */
export class MembershipProvider {
  private verifier: ZKVerifier;
  private accessCache: Map<string, { tier: number; expiresAt: number }>;

  constructor() {
    this.accessCache = new Map();
    
    this.verifier = new ZKVerifier({
      options: {
        checkExpiration: true,
        maxProofAge: 86400000, // 24 hours
        checkNullifier: true
      }
    });

    // Add trusted issuer
    this.verifier.addTrustedIssuer('membership-system', {
      id: 'membership-system',
      keyData: new Uint8Array(32),
      curve: 'bn128',
      provingScheme: 'groth16'
    });
  }

  /**
   * Verify membership access
   */
  public async verifyAccess(
    proof: Uint8Array,
    commitment: Uint8Array,
    requiredTier: number
  ): Promise<{
    granted: boolean;
    error?: string;
    tier?: number;
  }> {
    // Check cache first
    const cacheKey = Array.from(commitment).slice(0, 16).toString();
    const cached = this.accessCache.get(cacheKey);
    
    if (cached && Date.now() < cached.expiresAt) {
      return {
        granted: cached.tier >= requiredTier,
        tier: cached.tier
      };
    }

    // Reconstruct proof
    const zkProof = {
      proofData: proof,
      publicSignals: {
        commitment: Array.from(commitment).map(b => b.toString(16)).join(''),
        nullifier: '',
        timestamp: Date.now()
      },
      proofType: 'membership_verification',
      createdAt: Date.now(),
      expiresAt: Date.now() + 86400000,
      nullifier: new Uint8Array(32),
      constraints: [
        { attribute: 'tier', operator: '>=', value: requiredTier },
        { attribute: 'subscriptionActive', operator: '==', value: true }
      ]
    };

    const result = await this.verifier.verify(zkProof);

    if (result.isValid) {
      // Cache the result
      this.accessCache.set(result.nullifier, {
        tier: requiredTier, // In production, this would be extracted from signals
        expiresAt: Date.now() + 3600000 // 1 hour cache
      });

      return {
        granted: true,
        tier: requiredTier
      };
    }

    return {
      granted: false,
      error: result.error
    };
  }

  /**
   * Check cached access
   */
  public hasAccess(commitment: Uint8Array, requiredTier: number): boolean {
    const cacheKey = Array.from(commitment).slice(0, 16).toString();
    const cached = this.accessCache.get(cacheKey);
    
    if (!cached || Date.now() >= cached.expiresAt) {
      return false;
    }

    return cached.tier >= requiredTier;
  }

  /**
   * Revoke access for a user
   */
  public revokeAccess(commitment: Uint8Array): void {
    const cacheKey = Array.from(commitment).slice(0, 16).toString();
    this.accessCache.delete(cacheKey);
    
    // Revoke nullifier
    this.verifier.revokeNullifier(cacheKey);
  }
}

/**
 * Feature-gated component for React/HTML
 */
export class FeatureGate {
  private provider: MembershipProvider;

  constructor(provider: MembershipProvider) {
    this.provider = provider;
  }

  /**
   * Check if feature should be rendered
   */
  public canAccessFeature(feature: string, userTier: number): boolean {
    const requiredTier = this.getRequiredTier(feature);
    return userTier >= requiredTier;
  }

  /**
   * Get required tier for feature
   */
  private getRequiredTier(feature: string): number {
    const tiers = FEATURE_ACCESS[feature];
    if (!tiers || tiers.length === 0) {
      return MembershipTier.ENTERPRISE;
    }
    return Math.min(...tiers);
  }
}

/**
 * Demo usage
 */
export async function demoMembership() {
  console.log('=== Membership Verification Demo ===\n');

  // Create users with different tiers
  const users = [
    { tier: MembershipTier.FREE, active: true, name: 'Free User' },
    { tier: MembershipTier.PREMIUM, active: true, name: 'Premium User' },
    { tier: MembershipTier.ENTERPRISE, active: false, name: 'Expired Enterprise User' }
  ];

  const provider = new MembershipProvider();

  for (const user of users) {
    console.log(`--- Testing: ${user.name} ---`);
    
    const membership = new MembershipUser(user.tier as MembershipTier, user.active);
    await membership.initialize();

    // Test premium content access
    const features = ['basic-content', 'premium-content', 'enterprise-features'];
    
    for (const feature of features) {
      try {
        const { proof, commitment } = await membership.proveFeatureAccess(feature);
        const requiredTier = FEATURE_ACCESS[feature] ? 
          Math.min(...FEATURE_ACCESS[feature]) : MembershipTier.ENTERPRISE;
        
        const access = await provider.verifyAccess(proof, commitment, requiredTier);
        
        console.log(`  ${feature}: ${access.granted ? '✓ Access granted' : '✗ Access denied'}`);
        if (access.error) {
          console.log(`    Reason: ${access.error}`);
        }
      } catch (error) {
        console.log(`  ${feature}: ✗ Error - ${(error as Error).message}`);
      }
    }
    console.log();
  }

  // Demonstrate multi-feature proof
  console.log('--- Multi-Feature Proof Demo ---\n');
  
  const premiumUser = new MembershipUser(MembershipTier.PREMIUM, true);
  await premiumUser.initialize();

  const multiProof = await premiumUser.proveMultipleFeatures(['premium-content', 'api-access']);
  console.log('Generated multi-feature proof');
  console.log('Proof size:', multiProof.proof.length, 'bytes');
  console.log('This single proof grants access to multiple features based on tier requirements');
}

if (typeof require !== 'undefined' && require.main === module) {
  demoMembership().catch(console.error);
}
