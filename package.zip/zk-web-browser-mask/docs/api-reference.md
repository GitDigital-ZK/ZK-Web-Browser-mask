# API Reference

Complete API documentation for the ZK Web Browser Mask SDK.

## Table of Contents

- [ZKWebBrowserMask Class](#zkwebbrowsermask-class)
- [ZKVerifier Class](#zkverifier-class)
- [Utility Functions](#utility-functions)
- [Type Definitions](#type-definitions)

---

## ZKWebBrowserMask Class

The main class for creating and managing identity masks.

### Constructor

```typescript
new ZKWebBrowserMask(config: ZKMaskConfig): ZKWebBrowserMask
```

Creates a new mask instance with the specified configuration.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `config` | `ZKMaskConfig` | Yes | Configuration for the mask |

**Example:**

```typescript
import { ZKWebBrowserMask } from 'zk-web-browser-mask-sdk';

const mask = new ZKWebBrowserMask({
  attributes: {
    age: { type: 'uint8', value: 25 },
    country: { type: 'string', value: 'US' },
    verified: { type: 'boolean', value: true }
  },
  requireUserConsent: true,
  auditLogging: true
});
```

---

### Methods

#### `initialize(): Promise<void>`

Initializes the mask and generates the commitment and nullifier.

**Throws:** `ZKError` if initialization fails.

**Example:**

```typescript
await mask.initialize();
const commitment = mask.getCommitment();
```

---

#### `generateProof(request: ProofRequest): Promise<ZKProof>`

Generates a zero-knowledge proof for the specified constraints.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `request` | `ProofRequest` | Yes | Proof request configuration |

**Returns:** `Promise<ZKProof>` containing the proof data and public signals.

**Example:**

```typescript
const proof = await mask.generateProof({
  constraints: [
    { attribute: 'age', operator: '>=', value: 18 },
    { attribute: 'verified', operator: '==', value: true }
  ],
  issuer: 'my-kyc-provider',
  audience: 'my-dapp',
  expiration: Date.now() + 86400000
});
```

---

#### `getCommitment(): Commitment`

Returns the commitment for this mask.

**Returns:** `Commitment` object containing the commitment value, salt, and metadata.

**Example:**

```typescript
const commitment = mask.getCommitment();
console.log(commitment.value); // Uint8Array
```

---

#### `getNullifier(): Uint8Array`

Returns the nullifier for this mask.

**Returns:** `Uint8Array` containing the nullifier.

**Example:**

```typescript
const nullifier = mask.getNullifier();
console.log(bytesToHex(nullifier));
```

---

#### `export(): Promise<ExportedMask>`

Exports the mask data for backup.

**Returns:** `Promise<ExportedMask>` containing all mask data in a serializable format.

**Example:**

```typescript
const backup = await mask.export();
localStorage.setItem('mask_backup', JSON.stringify(backup));
```

---

#### `static import(data: ExportedMask): Promise<ZKWebBrowserMask>`

Creates a mask instance from exported data.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `data` | `ExportedMask` | Yes | Exported mask data |

**Returns:** `Promise<ZKWebBrowserMask>` new mask instance.

**Example:**

```typescript
const backup = JSON.parse(localStorage.getItem('mask_backup'));
const restoredMask = await ZKWebBrowserMask.import(backup);
```

---

#### `revoke(): Promise<void>`

Revokes this mask, preventing further proof generation.

**Example:**

```typescript
await mask.revoke();
// All subsequent generateProof() calls will throw
```

---

#### `isExpired(): boolean`

Checks if the mask has expired.

**Returns:** `boolean` true if expired.

---

#### `isRevoked(): boolean`

Checks if the mask has been revoked.

**Returns:** `boolean` true if revoked.

---

## ZKVerifier Class

Verifies zero-knowledge proofs on the service provider side.

### Constructor

```typescript
new ZKVerifier(config: ZKVerifierConfig): ZKVerifier
```

Creates a new verifier instance.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `config` | `ZKVerifierConfig` | No | Verifier configuration |

**Example:**

```typescript
const verifier = new ZKVerifier({
  trustedIssuers: trustedKeyMap,
  options: {
    checkExpiration: true,
    maxProofAge: 3600000
  }
});
```

---

### Methods

#### `verify(proof: ZKProof, commitment?: Commitment): Promise<VerificationResult>`

Verifies a zero-knowledge proof.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `proof` | `ZKProof` | Yes | The proof to verify |
| `commitment` | `Commitment` | No | Optional commitment for additional verification |

**Returns:** `Promise<VerificationResult>` containing verification status and details.

**Example:**

```typescript
const result = await verifier.verify(proof);

if (result.isValid) {
  console.log('Verification successful');
  console.log('Nullifier:', result.nullifier);
} else {
  console.log('Verification failed:', result.error);
}
```

---

#### `batchVerify(proofs: ZKProof[]): Promise<VerificationResult[]>`

Verifies multiple proofs in batch.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `proofs` | `ZKProof[]` | Yes | Array of proofs to verify |

**Returns:** `Promise<VerificationResult[]>` array of results.

---

#### `addTrustedIssuer(id: string, key: VerificationKey): void`

Adds a trusted issuer to the verifier.

**Example:**

```typescript
verifier.addTrustedIssuer('government-agency', {
  id: 'government-agency',
  keyData: verificationKeyBytes,
  curve: 'bn128',
  provingScheme: 'groth16'
});
```

---

#### `removeTrustedIssuer(id: string): boolean`

Removes a trusted issuer.

**Returns:** `boolean` true if removed successfully.

---

#### `isTrustedIssuer(issuerId: string): boolean`

Checks if an issuer is trusted.

**Returns:** `boolean` true if trusted.

---

#### `revokeNullifier(nullifier: string): void`

Adds a nullifier to the revocation list.

**Example:**

```typescript
verifier.revokeNullifier('0xabc123...');
```

---

#### `isRevoked(nullifier: string): boolean`

Checks if a nullifier is revoked.

**Returns:** `boolean` true if revoked.

---

## Utility Functions

### `hashAttributes(attributes: MaskAttributes, salt: Uint8Array): Promise<Uint8Array>`

Hashes attributes with a salt to create a commitment.

**Example:**

```typescript
const salt = await randomSalt(32);
const hash = await hashAttributes(attributes, salt);
```

---

### `randomSalt(length?: number): Promise<Uint8Array>`

Generates cryptographically secure random bytes for use as salt.

**Example:**

```typescript
const salt = await randomSalt(32);
```

---

### `bytesToHex(bytes: Uint8Array): string`

Converts bytes to a hex string.

**Example:**

```typescript
const hex = bytesToHex(new Uint8Array([255, 128, 0]));
// Returns: "ff8000"
```

---

### `hexToBytes(hex: string): Uint8Array`

Converts a hex string to bytes.

**Example:**

```typescript
const bytes = hexToBytes("ff8000");
// Returns: Uint8Array([255, 128, 0])
```

---

### `validateAttributeValue(value: unknown, type: string): boolean`

Validates an attribute value against its type.

**Example:**

```typescript
validateAttributeValue(25, 'uint8');  // true
validateAttributeValue(256, 'uint8'); // false
validateAttributeValue(true, 'boolean'); // true
```

---

## Type Definitions

### MaskAttributes

```typescript
interface MaskAttributes {
  [key: string]: AttributeValue;
}

type AttributeValue = 
  | { type: 'uint8'; value: number }
  | { type: 'uint32'; value: number }
  | { type: 'uint64'; value: bigint }
  | { type: 'boolean'; value: boolean }
  | { type: 'string'; value: string }
  | { type: 'bytes'; value: Uint8Array };
```

### Constraint

```typescript
interface Constraint {
  attribute: string;
  operator: '==' | '!=' | '>' | '<' | '>=' | '<=' | 'in' | 'notIn';
  value: number | string | boolean | bigint | number[] | string[];
}
```

### ProofRequest

```typescript
interface ProofRequest {
  constraints: Constraint[];
  issuer?: string;
  audience?: string;
  expiration?: number;
  nonce?: Uint8Array;
  metadata?: Record<string, unknown>;
  circuit?: string;
  provingTime?: 'speed' | 'balanced' | 'security';
}
```

### ZKProof

```typescript
interface ZKProof {
  proofData: Uint8Array;
  publicSignals: PublicSignals;
  proofType: string;
  createdAt: number;
  expiresAt?: number;
  issuer?: string;
  nullifier: Uint8Array;
  constraints: Constraint[];
}
```

### VerificationResult

```typescript
interface VerificationResult {
  isValid: boolean;
  publicSignals: PublicSignals;
  nullifier: string;
  failedConstraints?: Constraint[];
  error?: string;
  metadata?: Record<string, unknown>;
}
```

---

## Error Handling

All SDK methods may throw `ZKError` exceptions on failure:

```typescript
try {
  const proof = await mask.generateProof({ constraints });
} catch (error) {
  if (error instanceof ZKError) {
    console.error('Error type:', error.type);
    console.error('Message:', error.message);
    console.error('Details:', error.details);
  }
}
```

### Error Types

| Type | Description |
|------|-------------|
| `INVALID_CONFIG` | Invalid configuration provided |
| `PROOF_GENERATION_FAILED` | Failed to generate proof |
| `VERIFICATION_FAILED` | Proof verification failed |
| `INVALID_CONSTRAINT` | Invalid constraint specification |
| `MISSING_ATTRIBUTE` | Required attribute not found |
| `STORAGE_ERROR` | Storage operation failed |
| `CRYPTO_ERROR` | Cryptographic operation failed |
| `NETWORK_ERROR` | Network request failed |
| `TIMEOUT` | Operation timed out |
| `USER_REJECTED` | User rejected the request |
| `EXPIRED` | Proof or mask has expired |
| `REVOKED` | Mask has been revoked |

---

## Browser Extension API

The browser extension exposes a simplified API for web integration:

```typescript
// Check if user has a mask
const hasMask = await window.zkBrowserAPI.hasMask('example.com');

// Request a proof from the user
const proof = await window.zkBrowserAPI.requestProof({
  constraints: [
    { attribute: 'age', operator: '>=', value: 18 }
  ],
  reason: 'Age verification required'
});
```

---

## Next Steps

- [Installation Guide](installation.md)
- [Quick Start Tutorial](quickstart.md)
- [Examples](../examples/)
- [Security Best Practices](../docs/security.md)
